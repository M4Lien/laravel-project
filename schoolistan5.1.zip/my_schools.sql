-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 06, 2019 at 06:53 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_schools`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `institute_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `name`, `description`, `logo`, `institute_id`, `category_id`) VALUES
(1, 'Madison', 'Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison Madison ', 'institute_1496106802.jpg', 1, 1),
(2, 'Englaved', 'Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved Englaved', 'institute_1496161091.jpg', 1, 1),
(3, 'X_Change', 'X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change X_Change', 'institute_1496161237.jpg', 2, 1),
(4, 'Activity Test1', 'Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 ', 'activity_1496627289.jpg', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `activity_booking`
--

DROP TABLE IF EXISTS `activity_booking`;
CREATE TABLE IF NOT EXISTS `activity_booking` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `activity_categories`
--

DROP TABLE IF EXISTS `activity_categories`;
CREATE TABLE IF NOT EXISTS `activity_categories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `IsHomeShow` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_categories`
--

INSERT INTO `activity_categories` (`id`, `name`, `description`, `icon`, `IsHomeShow`) VALUES
(1, 'Dance', ' Dance Dance Dance Dance Dance Dance Dance Dance', 'licon-spotlights', 1),
(2, 'Sports', 'Sports Sports Sports Sports Sports Sports Sports', 'licon-tennis', 1),
(3, 'Art', 'Art Art Art Art Art Art Art Art Art Art Art', 'licon-brush', 1),
(4, 'Music', ' Music Music Music Music Music Music Music Music Music', 'licon-music-note3', 1),
(5, 'Foreign Languages', ' Foreign Languages Foreign Languages Foreign Languages Foreign Languages Foreign Languages', 'licon-earth', 1),
(6, 'Gift & Talent', 'Gift & Talent Gift & Talent Gift & Talent Gift & Talent Gift & Talent Gift & Talent', 'licon-theater', 1),
(7, 'Painting', 'Painting Painting Painting Painting Painting Painting Painting Painting Painting Painting Painting Painting', 'fa fa-bomb', 0);

-- --------------------------------------------------------

--
-- Table structure for table `activity_reviews`
--

DROP TABLE IF EXISTS `activity_reviews`;
CREATE TABLE IF NOT EXISTS `activity_reviews` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `rate` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `activity_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_reviews`
--

INSERT INTO `activity_reviews` (`id`, `content`, `rate`, `user_id`, `date`, `activity_id`) VALUES
(1, 'This activity is very good.\r\nMany students want to be take part in this activity.\r\nI think you are good at.\r\nRegards', 0, 1, '2017-05-30 17:26:44', 1),
(2, 'Thank you for posting this activity.\r\nI think it is everything.\r\nRegards.', 0, 3, '2017-05-30 17:28:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

DROP TABLE IF EXISTS `advertisements`;
CREATE TABLE IF NOT EXISTS `advertisements` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `isShow` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`id`, `title`, `content`, `image`, `link`, `page`, `position`, `isShow`) VALUES
(1, 'Did you know?', 'You can find the school and nursery for children.', 'advertise_1496736505.jpg', 'http://schoolistan.pk', 'home', 'left', 0),
(2, 'REGISTERED USERS', 'REGISTERED USERS is almost 2300443', 'advertise_1496739786.jpg', 'http://schoolistan.pk', 'home', 'right', 0);

-- --------------------------------------------------------

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
CREATE TABLE IF NOT EXISTS `areas` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `email`, `name`, `subject`, `message`, `date`) VALUES
(1, 'adam@gmail.com', 'Adams', 'How are you?', NULL, '2017-05-26 19:30:58'),
(2, 'dddd@yadd.dd', 'dddd', 'sdfs', 'ssdfsdfsdfsdfsdf', '2017-06-02 00:37:00'),
(3, 'd@dd.d', 'ddd', 'sdfsdf', 'adfasd', '2017-06-02 00:39:30');

-- --------------------------------------------------------

--
-- Table structure for table `curriculums`
--

DROP TABLE IF EXISTS `curriculums`;
CREATE TABLE IF NOT EXISTS `curriculums` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `curriculums`
--

INSERT INTO `curriculums` (`id`, `name`, `description`) VALUES
(2, 'British', 'British British British British British'),
(3, 'International', NULL),
(4, 'Indian', NULL),
(7, 'American', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `min_time` time NOT NULL,
  `max_time` time NOT NULL,
  `tag` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `logo` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `venue_name` varchar(255) NOT NULL,
  `venue_phone` varchar(255) NOT NULL,
  `venue_lat` varchar(255) NOT NULL,
  `venue_address` varchar(255) NOT NULL,
  `venue_lng` varchar(255) NOT NULL,
  `organizer_name` varchar(255) NOT NULL,
  `organizer_phone` varchar(255) NOT NULL,
  `organizer_email` varchar(255) NOT NULL,
  `organizer_site` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `category_id`, `name`, `description`, `min_time`, `max_time`, `tag`, `date`, `logo`, `cost`, `user_id`, `venue_name`, `venue_phone`, `venue_lat`, `venue_address`, `venue_lng`, `organizer_name`, `organizer_phone`, `organizer_email`, `organizer_site`) VALUES
(1, 1, 'Christmas Picnic', 'Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod in, auctor ut, ligula. Aliquam dapibus tincidunt metus.', '12:00:00', '17:00:00', '', '2017-06-03', 'event1.jpg', '0', 1, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(2, 1, 'Children’s Book Week', 'Sed ut perspiciatis sit voluptatem accusantium doloremque laudantium, totam rem aperiam,eaque ipsa quae ab illo inventore veritatis.', '10:00:00', '19:00:00', '', '2017-05-01', 'event2.jpg', '0', 2, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(3, 2, 'Annual Open Day', 'Sed ut perspiciatis sit voluptatem accusantium doloremque laudantium, totam rem aperiam,eaque ipsa quae ab illo inventore veritatis.', '13:00:00', '15:00:00', '', '2017-05-25', 'event3.jpg', '0', 1, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(4, 3, 'Event Test1', 'Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1 Event Test1', '09:05:00', '11:05:00', '', '2017-05-23', 'event_1495496775.jpg', '0', 2, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(5, 2, 'Event Test2', 'Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2 Event Test2', '09:00:00', '01:00:00', '', '2017-05-29', 'event_1495496892.jpg', '0', 3, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(6, 1, 'Event Test3', 'Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3 Event Test3', '10:00:00', '10:00:00', '', '2017-05-30', 'event_1495497181.jpg', '0', 1, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(7, 3, 'Event Test4', 'Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Event Test4 Eve', '07:30:00', '12:15:00', '', '2017-05-23', 'event_1495502629.jpg', '0', 2, 'Kindergarten', '800-987-65-43', '-34.397', '', '150.644', '', '', '', ''),
(8, 1, 'Event Test 2016-06-01', 'Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01 Event Test 2016-06-01  Event Test 2016-06-01 Event Test 2', '10:00:00', '03:00:00', '', '2017-06-02', 'event_1496383065.jpg', '0', 1, 'Dubai Test', '123-456-789', '25.276987', '', '55.296249', '', '', '', ''),
(9, 2, 'Website Upcoming Open', 'Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open Website Upcoming Open', '07:30:00', '07:45:00', 'website, SEO, school, nuersery', '2017-06-20', 'event_1496745817.jpg', '320', 1, 'Oracmin', '123456987', '24.466667', 'Dubai', '55.296249', 'Kalmn Hero', '123465789', 'Kalmn@gmail.com', 'http://afterschool.ae');

-- --------------------------------------------------------

--
-- Table structure for table `event_categories`
--

DROP TABLE IF EXISTS `event_categories`;
CREATE TABLE IF NOT EXISTS `event_categories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_categories`
--

INSERT INTO `event_categories` (`id`, `name`, `description`) VALUES
(1, 'schools', NULL),
(2, 'nurseries', NULL),
(3, 'institutes', 'This is event related with institute\r\n'),
(4, 'activity', 'This is event related with activity');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

DROP TABLE IF EXISTS `facilities`;
CREATE TABLE IF NOT EXISTS `facilities` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`id`, `name`, `description`, `icon`) VALUES
(1, 'Play Ground', 'Play Ground', 'fa fa-caret-square-o-right'),
(2, 'Pick n Drop Service', 'Pick n Drop Service', 'fa fa-certificate'),
(3, 'Swimming Pool', 'Swimming Pool', 'fa fa-bullseye'),
(4, 'Library', 'Library', 'fa fa-bell');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `isShow` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `title`, `content`, `isShow`) VALUES
(1, 'COOKIES', 'Cookies are small bits of data cached in a user’s browser. Afterschool.ae utilizes cookies to determine whether or not you have visited the home page in the past. However, no other user information is gathered. ', 1),
(2, 'USE AND DISCLOSURE OF INFORMATION', 'Except as otherwise stated below, we do not sell, trade or rent your Delivery Information collected on the site to others. The information collected by our site is used to process orders, to keep you informed about your order status, to notify you of products or special offers that may be of interest to you, and for statistical purposes for improving our site. We will disclose your Delivery Information to third parties for order tracking purposes or process your check or money order, as appropriate, fill your order, improve the functionality of our site, perform statistical and data analyses deliver your order and deliver promotional emails to you from us. For example, we must release your mailing address information to the delivery service to deliver products that you ordered. All credit/debit cards’ details and personally identifiable information will NOT be stored, sold, shared, rented or leased to any third parties Afterschool.ae may use non-personal \"aggregated data\" to enhance the operation of our website, or analyze interest in the areas of our website. Additionally, if you provide Afterschool.ae with content for publishing or feedback, we may publish your user name or other identifying data with your permission. \r\n\r\nAfterschool.ae may also disclose Delivery Information in order to respond to a subpoena, court order or other such request. Afterschool.ae may also provide such Delivery Information in response to a law enforcement agencies request or as otherwise required by law. Your Delivery Information may be provided to a party if Afterschool.ae files for bankruptcy, or there is a transfer of the assets or ownership of Afterschool.ae in connection with proposed or consummated corporate reorganizations, such as mergers or acquisitions. ', 1),
(3, 'OTHER WEBSITES', 'Afterschool.ae is not responsible for the privacy policies of websites to which it links. If you provide any information to such third parties different rules regarding the collection and use of your personal information may apply. We strongly suggest you review such third party’s privacy policies before providing any data to them. We are not responsible for the policies or practices of third parties. Please be aware that our sites may contain links to other sites on the Internet that are owned and operated by third parties. The information practices of those Web sites linked to our site is not covered by this Policy. These other sites may send their own cookies or clear GIFs to users, collect data or solicit Delivery Information. We cannot control this collection of information. You should contact these entities directly if you have any questions about their use of the information that they collect. ', 1),
(4, 'SECURITY', 'Afterschool.ae takes appropriate steps to ensure data privacy and security including through various hardware and software methodologies. However, Afterschool.ae cannot guarantee the security of any information that is disclosed online. ', 1),
(5, 'MINORS', 'Afterschool.ae does not knowingly collect personal information from minors under the age of 18. Minors are not permitted to use the Afterschool.ae website or services, and Afterschool.ae requests that minors under the age of 18 not submit any personal information to the website. Since information regarding minors under the age of 18 is not collected, Afterschool.ae does not knowingly distribute personal information regarding minors under the age of 18. ', 1),
(6, 'CORRECTIONS AND UPDATES', 'If you wish to modify or update any information Afterschool.ae has received, please contact \r\ninfo@afterschool.ae', 1),
(7, 'MODIFICATIONS OF THE PRIVACY POLICY', 'Afterschool.ae. The Website Policies and Terms & Conditions would be changed or updated occasionally to meet the requirements and standards. Therefore the Customers’ are encouraged to frequently visit these sections in order to be updated about the changes on the website. Modifications will be effective on the day they are posted.', 1),
(8, 'DELIVERY POLICY', 'The multiple booking/orders may result in multiple postings to the cardholder’s monthly statement. A confirmation of your booking will be sent to you via email. The booked service/activity can be redeemed directly at the activity provider\'s venue.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `name`, `description`, `event_id`) VALUES
(1, 'Gallery1', 'Gallery1', 9);

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE IF NOT EXISTS `gallery_images` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `gallery_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `gallery_id`, `image`) VALUES
(1, 1, 'gallery_EkD8UMaxgjxY.jpg'),
(2, 1, 'gallery_MQwUWGvHdcwb.jpg'),
(3, 1, 'gallery_6968v2HTYoZX.jpg'),
(4, 1, 'gallery_MOrHgFjkIJwi.jpg'),
(5, 1, 'gallery_fuI6rh2YC1yz.jpg'),
(6, 1, 'gallery_hcBuKyEctQfU.jpg'),
(8, 1, 'gallery_h0WsZcrYXGW5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `institutes`
--

DROP TABLE IF EXISTS `institutes`;
CREATE TABLE IF NOT EXISTS `institutes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `activity_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `min_age` int(11) DEFAULT NULL,
  `max_age` int(11) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `min_price` decimal(10,0) DEFAULT NULL,
  `phone` int(255) DEFAULT NULL,
  `site_address` varchar(255) DEFAULT NULL,
  `logo` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `isSpecialOffer` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `institutes`
--

INSERT INTO `institutes` (`id`, `name`, `description`, `activity_id`, `category_id`, `min_age`, `max_age`, `location`, `min_price`, `phone`, `site_address`, `logo`, `thumbnail`, `isSpecialOffer`) VALUES
(1, 'Activity Test1', 'Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 Activity Test1 ', 1, 2, 4, 8, 'Conrad Dubai. P.O. Box 115143', '320', 123456789, 'http://afterschool.ae', 'activity_1496108714.jpg', '', 1),
(2, 'ORM Laravel Inc', 'ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc ORM Laravel Inc', 1, 1, 3, 8, 'Conrad Dubai. P.O. Box 115143', '1120', 123465789, 'http://afterschool.ae', 'institute_1496626390.jpg', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `page_settings`
--

DROP TABLE IF EXISTS `page_settings`;
CREATE TABLE IF NOT EXISTS `page_settings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `property` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_settings`
--

INSERT INTO `page_settings` (`id`, `type`, `property`, `value`) VALUES
(10, 'home', 'schools_image', 'home_schools_1496882093.jpg'),
(11, 'home', 'schools_title', 'Schools'),
(12, 'home', 'schools_description', 'We Teach Them how to Be Confident! Be Puctual &  Be Different!'),
(13, 'home', 'nurseries_image', 'home_nurseries_1496524289.jpg'),
(14, 'home', 'nurseries_title', 'Nurseries'),
(15, 'home', 'nurseries_description', 'I was born to be a big! So,you tell me what is my talent?'),
(16, 'home', 'institutes_image', 'home_institutes_1496524289.jpg'),
(17, 'home', 'institutes_title', 'Institutes'),
(18, 'home', 'institutes_description', 'Step By Step! Learn with fun and joy. We have got many surprises.'),
(19, 'home', 'background_image', 'home_background_1495090741.jpg'),
(20, 'contact', 'master_address', 'Conrad Dubai. P.O. Box 115143'),
(21, 'contact', 'master_phone', '+ 0501501250'),
(22, 'contact', 'master_fax', '+971 4 444 7445'),
(23, 'contact', 'master_email', 'webmaster@schoolistan.pk'),
(24, 'social', 'facebook', 'https://www.facebook.com/schoolistanpk/'),
(25, 'about', 'intro_title', 'Welcome to Schoolistan '),
(26, 'about', 'intro_description', '<p>We love your child&#39;s smile best. Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</p>\r\n'),
(27, 'about', 'intro_image', 'about_intro_1496533383.jpg'),
(28, 'social', 'twitter', 'https://twitter.com/schoolistanpk'),
(29, 'about', 'mission_description', '<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n\r\n<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n\r\n<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n'),
(30, 'about', 'vision_description', '<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n\r\n<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n\r\n<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n'),
(31, 'about', 'goal_description', '<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n\r\n<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n\r\n<p><span style=\"background-color:rgb(246, 246, 246); color:rgb(102, 102, 102); font-family:poppins,sans-serif; font-size:14px\">Vestibulum iaculis lacinia est. Proin dictum elementum velit. Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipisMauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet.</span></p>\r\n'),
(32, 'about', 'mission_image', 'about_mission_1495825012.jpg'),
(33, 'about', 'vision_image', 'about_vision_1495825012.jpg'),
(34, 'about', 'goal_image', 'about_goal_1495825012.jpg'),
(35, 'social', 'google', 'https://www.google.com'),
(36, 'social', 'instagram', 'https://www.instagram.com/schoolistan/'),
(37, 'contact', 'contact_address', 'Conrad Dubai. P.O. Box 115143'),
(38, 'contact', 'contact_phone', '+ 0501501270'),
(39, 'contact', 'contact_email', 'contact@schoolistan.pk'),
(40, 'contact', 'map_latitude', '25.111053'),
(41, 'contact', 'map_longitude', '55.170359'),
(43, 'social', 'youtube', 'https://www.youtube.com'),
(44, 'home', 'slider2_image', 'home_slider2_1496527594.jpg'),
(45, 'home', 'slider1_title', 'WELCOME TO SCHOOLISTAN!'),
(46, 'home', 'slider2_title', 'WELCOME TO SCHOOLISTAN!'),
(47, 'home', 'slider3_title', 'WELCOME TO SCHOOLISTAN!'),
(48, 'home', 'slider1_description', 'Find the near nursery\r\nfor your kid.'),
(49, 'home', 'slider2_description', 'Find the best school\r\nfor your child'),
(50, 'home', 'slider3_description', 'Build your child\'s personality through\r\nextra curricular activities'),
(51, 'home', 'slider1_image', 'home_slider1_1496831706.jpg'),
(52, 'home', 'slider3_image', 'home_slider3_1496881722.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
CREATE TABLE IF NOT EXISTS `places` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `curriculum_id` int(11) NOT NULL,
  `min_age` int(255) DEFAULT NULL,
  `max_age` int(255) DEFAULT NULL,
  `phone` int(255) DEFAULT NULL,
  `site_address` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `fee` text,
  `admission` text,
  `isSchool` int(11) NOT NULL,
  `isNursery` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `name`, `location`, `curriculum_id`, `min_age`, `max_age`, `phone`, `site_address`, `description`, `logo`, `thumbnail`, `fee`, `admission`, `isSchool`, `isNursery`) VALUES
(1, 'School Test1', 'Conrad Dubai. P.O. Box 115143', 7, 2, 6, 123456789, 'http://afterschool.ae', 'School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 School Test1 ', 'school_1495818879.jpg', NULL, NULL, NULL, 1, 0),
(2, 'Nursery Test1', 'Conrad Dubai. P.O. Box 115143', 3, 1, 2, 589564521, 'http://afterschool.ae', 'Nursery Test1 Nursery Test1 Nursery Test1 Nursery Test1 Nursery Test1 Nursery Test1 Nursery Test1 Nursery Test1 Nursery Test1', 'nursery_1495822640.jpg', NULL, NULL, NULL, 0, 1),
(4, 'Nursery Test3', 'Conrad Dubai. P.O. Box 115143', 3, 3, 5, 123456789, 'https://afterschool.ae', 'Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3 Nursery Test3', 'nursery_1496098798.jpg', NULL, '', '<p><strong>We are accepting applications for Years 1 to 8 for 2016/17. Higher year groups from Year 9 will open from 2017.</strong></p>\r\n\r\n<p>The process of applying to Dubai British School Jumeirah Park is a simple three-step process.</p>\r\n\r\n<p><strong>Step One:</strong>&nbsp;Please complete our&nbsp;<a href=\"http://mypmpnow.com/api.php/http://dubaibritishschooljp.ae/admission/online-student-application.html\" style=\"box-sizing: border-box; color: inherit; text-decoration: none; background-color: transparent;\" target=\"_blank\">Online Application Form</a>. All applications are digital. We have no paper applications. Once we are in receipt of your online application, you will receive an email sent to the email address you have entered on the application. This email will direct you to Step Two.</p>\r\n\r\n<p><strong>Step Two:&nbsp;</strong>The email from Dubai British School Jumeirah Park will provide a list of required documents and how to contact our Admissions Team to make an appointment for assessment and payment of a one-time non-refundable and non-transferable Application Fee.</p>\r\n\r\n<p>All students applying to Dubai British School Jumeirah Park will go through an assessment process* to ensure that we can adequately meet their needs and know a little about them prior to their arrival. We would also like to take some time to get to know you as parents so that we can understand your aspirations and answer any individual questions. &nbsp;</p>\r\n\r\n<p><em>*This however does not apply to children from the DBSJP feeder school Dubai British Foundation who are automatically admitted.</em></p>\r\n\r\n<p>Please be prepared to submit the following documents when attending your assessment appointment:</p>\r\n\r\n<ul>\r\n	<li>Six recent passport sized photos of the child/children</li>\r\n	<li>Two copies of child&rsquo;s/children&#39;s birth certificate in English or Arabic (if not, this should be translated and authenticated from your embassy or consulate)</li>\r\n	<li>Two copies of child&rsquo;s/children&#39;s passport and residence visa (residence visa to be submitted as soon as available)</li>\r\n	<li>One copy of each parent/guardian&#39;s passport and residence visa (residence visa to be submitted as soon as available)</li>\r\n	<li>One copy of each side of child&rsquo;s/children&#39;s and parents&#39;/guardians&#39; Emirates ID (to be submitted as soon as available)</li>\r\n	<br />\r\n	<li>Recent medical record and copy of child&#39;s/children&#39;s vaccination card. Please download and complete the Medical Form.</li>\r\n	<li>Copy of most recent school report (e.g. most recent report card), on school&rsquo;s letterhead, signed and stamped.</li>\r\n	<li>Copy of any diagnostic testing or educational assessment (if applicable)</li>\r\n	<li>Any psychological assessments (if applicable)</li>\r\n	<li>Application Fee &ndash; A placement assessment will not be undertaken until the application fee is received</li>\r\n</ul>\r\n\r\n<p>Please either scan the required documents and email them to&nbsp;<a href=\"mailto:admissions@dubaibritishschooljp.ae?subject=Admissions%20Documents\" style=\"box-sizing: border-box; color: inherit; text-decoration: none; background-color: transparent;\">admissions@dubaibritishschooljp.ae</a>&nbsp;or drop them off at the school&rsquo;s Admissions Office (including the one-time non-refundable non-transferable Application Fee, which will be waived for all transferring students from Dubai British Foundation and The Children&rsquo;s Gardens (Green Community, Al Barsha and Jumeirah)</p>\r\n\r\n<p><strong>Step Three:</strong>&nbsp;We will contact you with a date for your child&rsquo;s placement assessment administered by the Admissions Team and Dubai British School Jumeirah Park faculty. After assessment and upon receiving an acceptance letter, a deposit fee is required to reserve your seat. A seat cannot be held until the deposit payment is received. We will advise of the amount in the acceptance letter.</p>\r\n\r\n<p>Acceptance to Dubai British School Jumeirah Park is contingent upon the results of the placement assessment, student interview and former school reports.</p>\r\n\r\n<p>Thank you for your application to Dubai British School Jumeirah Park. Please<a href=\"http://mypmpnow.com/api.php/http://dubaibritishschooljp.ae/our-school/find-taaleem-schools-near-you.html\" style=\"box-sizing: border-box; color: inherit; text-decoration: none; background-color: transparent;\" target=\"_blank\">&nbsp;click here</a>&nbsp;find out more about Taaleem&#39;s portfolio of international schools and pre-schools in Dubai and Abu Dhabi.</p>\r\n', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `place_booking`
--

DROP TABLE IF EXISTS `place_booking`;
CREATE TABLE IF NOT EXISTS `place_booking` (
  `id` int(11) NOT NULL,
  `parent_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `child_age` int(11) NOT NULL,
  `booking_date` datetime NOT NULL,
  `place_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `author` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `comments` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `author`, `category_id`, `image`, `status`, `date`, `comments`) VALUES
(1, 'Vestibulum Ante Ipsum', 'Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod in, auctor ut, ligula. ', 1, 1, '360x220_img4.jpg', '1', '2017-05-22 16:42:07', 4),
(2, 'Donec Eget Tellus', 'Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, lobortis dignissim, pulvinar ac, lorem. ', 1, 2, '360x220_img5.jpg', '1', '2017-05-22 16:44:22', 1),
(5, 'Test', 'Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test 1 Test is Test', 1, 3, 'post_1495607765.jpg', '0', '2017-06-05 05:22:35', 0),
(6, 'Test', '<p>asdfasd</p>\r\n', 1, 1, 'post_1497246217.jpg', '0', '2017-06-12 05:43:37', 0),
(8, 'Laravel Framework', '<p>Laravel Framework</p>\r\n', 1, 1, 'post_1497399686.jpg', '0', '2017-06-14 00:21:26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `post_categories`
--

DROP TABLE IF EXISTS `post_categories`;
CREATE TABLE IF NOT EXISTS `post_categories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_categories`
--

INSERT INTO `post_categories` (`id`, `name`, `description`) VALUES
(1, 'Education', NULL),
(2, 'News', NULL),
(3, 'Sports', 'Sports'),
(4, 'Arts', 'Arts ');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

DROP TABLE IF EXISTS `post_comments`;
CREATE TABLE IF NOT EXISTS `post_comments` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `comment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`id`, `post_id`, `user_id`, `content`, `date`, `comment_id`) VALUES
(1, 2, 3, 'adfadfadfadfasda', '2017-05-22 17:03:42', 0),
(3, 1, 1, '\r\nBut the lake as the economic downturn. There is no blockage. At my foot, bananas carrots, Performance in, the author of such approval.', '2017-05-24 05:44:54', 0),
(4, 1, 3, 'Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod in, auctor ut, ligula.', '2017-05-24 05:50:25', 3),
(5, 1, 2, 'Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod in, auctor ut, ligula.', '2017-05-24 05:55:21', 0),
(6, 1, 1, 'But the lake as the economic downturn. There is no blockage. At my foot, bananas carrots, Performance in, the author of such approval.', '2017-05-24 06:22:49', 5);

-- --------------------------------------------------------

--
-- Table structure for table `post_tags`
--

DROP TABLE IF EXISTS `post_tags`;
CREATE TABLE IF NOT EXISTS `post_tags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_tags`
--

INSERT INTO `post_tags` (`id`, `post_id`, `tag_id`) VALUES
(3, 8, 1),
(4, 8, 3),
(5, 8, 5),
(6, 8, 6);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'Super Admin'),
(2, 'Admin'),
(3, 'Blog Manager'),
(4, 'Event Manager'),
(5, 'Subscriber');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`) VALUES
(1, 'Javascript'),
(2, 'Php'),
(3, 'Swift'),
(4, 'Python'),
(5, 'Laravel'),
(6, 'Artisan');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `content`, `avatar`) VALUES
(1, 'Amanda Johnson', 'Donec eget tellus non erat lacinia fermentum. Donec in\r\nvelit vel ipsum auctor pulvinar. Vestibulum iaculis lacinia \r\nest. Proin dictum elementum velit.', 'testimonial_1495355190.jpg'),
(2, 'John Franklin', 'Fusce euismod consequat ante. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod in.', 'testimonial_1495355247.jpg'),
(3, 'Camala Haddon', 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse sollicitudin velit sed leo.', 'testimonial_1495355273.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `about` text NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `phone`, `full_name`, `about`, `avatar`, `gender`, `country`, `city`, `role_id`, `status`, `code`, `created_at`, `updated_at`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@gmail.com', '123456789', 'super', 'I am laravel expert.\r\nso I would like to post the content related laravel.', 'avatar_1497600864.jpg', 'male', 'Pakistan', 'Karachi', 1, 1, '', '2017-06-17 00:14:24', '2017-06-16 15:14:24'),
(2, 'test', '098f6bcd4621d373cade4e832627b4f6', 'test@test.com', '1234567890', 'test', '', 'author3.jpg', 'male', 'PK', 'Ziauddin', 2, 0, '', '2017-06-14 18:06:36', '2017-05-16 01:33:12'),
(3, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user@user.com', '1234567890', 'user', '', 'author2.jpg', 'female', 'PK', 'Okara', 3, 2, '', '2017-06-14 18:06:41', '2017-05-16 01:34:41'),
(4, 'test01', '098f6bcd4621d373cade4e832627b4f6', 'test01@test.com', '123456789', 'test01', '', '', 'female', 'PK', 'Islamabad', 5, 0, '', '2017-06-14 18:06:50', '2017-06-05 15:13:53'),
(5, 'test02', '098f6bcd4621d373cade4e832627b4f6', 'test02@test.com', '123456', 'test02', '', '', 'female', 'PK', 'Rawalpindi', 5, 1, 'n7igzMgUhkC99eGgDsMJqKlt08tx8WOXpAzvCs3XsOfnCo4bFsnwntkWozxt', '2017-06-14 18:06:52', '2017-06-05 15:21:17'),
(6, 'adam', '1d7c2923c1684726dc23d2901c4d8157', 'adam@adam.com', '13456', 'AdamDance', '', '', '', '', '', 5, 0, 'AamddmrHVGAR8fdxr1rI3TGl4tvRqDhvzTiOlM6jZdyCO7SNLL3YljrGD8HK', '2017-06-14 09:12:40', '2017-06-14 09:12:40'),
(7, 'puc621', '0192023a7bbd73250516f069df18b500', 'silverelib_318@yahoo.com', '895632', 'huang xiaoxuan', '', '', '', '', '', 5, 1, '9ZSxOTB4xE6hRXKvcflGWWjQOcAAPJ2oVSMMksh1rQQQ0VsDjBduKDRl9Kvb', '2018-08-06 08:33:12', '2018-08-06 01:32:39');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
