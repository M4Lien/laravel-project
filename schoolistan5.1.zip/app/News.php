<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class News extends Model {

	protected $table = 'events';

	protected $fillable = ['name', 'description', 'min_time', 'max_time', 'date', 'logo', 'expired_date'];

}
