<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostComment extends Model {

	protected $table = 'post_comments';

	protected $fillable = ['id', 'post_id', 'user_id', 'content', 'date', 'comment_id'];

    public $timestamps = false;

    protected $appends = ['reply'];

    public function getUser(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function getReplyAttribute(){
        return $this::where('comment_id', $this->id)->get();
    }

}
