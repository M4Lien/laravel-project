<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActivityReview extends Model {

	protected $table = 'activity_reviews';

	protected $fillable = ['id', 'content', 'rate', 'user_id', 'date', 'activity_id'];

    public $timestamps = false;

    public function getUser(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }

}
