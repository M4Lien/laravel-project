<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Institute extends Model {

	protected $table = 'institutes';

	protected $fillable = ['name', 'description', 'activity_id', 'category_id', 'min_age', 'max_age', 'location', 'min_price', 'phone', 'site_address', 'logo', 'thumbnail', 'isSpecialOffer'];

    public $timestamps = false;

    public function getActivity(){
        return $this->hasOne(Activity::class, 'id', 'activity_id');
    }

    public function getCategory(){
        return $this->hasOne(ActivityCategory::class, 'id', 'category_id');
    }
}
