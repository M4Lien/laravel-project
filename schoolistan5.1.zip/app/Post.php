<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model {

	protected $table = 'posts';

	protected $fillable = ['id', 'title', 'content', 'author', 'category_id', 'image', 'status', 'date', 'comments'];

    public $timestamps = false;

    protected $appends = ['tags'];

    public function getUser(){
        return $this->hasOne(User::class, 'id', 'author');
    }

    public function getCategory(){
        return $this->hasOne(PostCategory::class, 'id', 'category_id');
    }

    public function getTagsAttribute(){
        $currentTagsForPost = PostTag::where('post_id', $this->id)->get();
        $currentTagsArray = [];
        foreach($currentTagsForPost as $ctp){
            array_push($currentTagsArray, $ctp->getTag->name);
        }
        return implode(',', $currentTagsArray);
    }

}
