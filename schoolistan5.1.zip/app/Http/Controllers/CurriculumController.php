<?php

namespace App\Http\Controllers;
use App\Curriculum;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Place;

class CurriculumController extends BaseController
{
    public function getCurriculumList(){
        $curriculum = Curriculum::all();
        $flag = "curriculumList";
        return View::make('pages.backend.curriculum.list', compact('flag', 'curriculum'));
    }
    public function getCurriculumAdd(){
        $isEdit = false;
        $flag = "curriculumAdd";
        return View::make('pages.backend.curriculum.add', compact('flag', 'isEdit'));
    }
    public function createCurriculum(){
        $rules = array(
            'name' => 'required',
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $curriculum = new Curriculum();
            $curriculum->name = Input::get('name');
            $curriculum->description = Input::get('description');
            $curriculum->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateCurriculum($id){
        $rules = array(
            'name' => 'required',
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $curriculum = Curriculum::find($id);
            $curriculum->name = Input::get('name');
            $curriculum->description = Input::get('description');
            $curriculum->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function getCurriculumEdit($id){
        $flag = "curriculumAdd";
        $isEdit = true;
        $curriculum = Curriculum::find($id);
        return View::make('pages.backend.curriculum.add', compact('flag', 'curriculum', 'isEdit'));
    }
    public function deleteCurriculum($id){
        $places = Place::where('curriculum_id', $id)->get();
        if($places->count() == 0){
            Curriculum::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. There are nurseries and schools associated with this curriculum.");
        }
    }
}
