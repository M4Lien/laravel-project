<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use App\OurEvent;
use App\Advertisement;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use App\PostCategory;
use App\Post;
use App\Tag;
use App\PostTag;
use App\PostComment;

class PostController extends BaseController
{
    public function goAddPage(){
        $isEdit = false;
        $categories = PostCategory::all();
        $tags = Tag::all()->lists('name');
        $flag = "blogAdd";
        return View::make('pages.backend.blog.add', compact('flag', 'categories', 'isEdit', 'tags'));
    }
    public function goEditPage($id){
        $isEdit = true;
        $post = Post::find($id);
        $categories = PostCategory::all();
        $tags = Tag::all()->lists('name');
        $flag = "blogAdd";
        return View::make('pages.backend.blog.add', compact('flag', 'categories', 'isEdit', 'post', 'tags'));
    }
    public function getPostList(){
        $posts = Post::all();
        $flag = "blogList";
        return View::make('pages.backend.blog.list', compact('flag', 'posts'));
    }
    public function createPost(){
        $rules = array(
            'content' => 'required',
            'title' =>'required',
            'category_id' => 'required',
            'tags' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $post = new Post();
            $post->title = Input::get('title');
            $post->content = Input::get('content');
            $post->author = Session::get('user')->id;
            $post->category_id = Input::get('category_id');
            $post->comments = 0;
            $post->status = 0;
            $post->date = date('Y-m-d H:i:s');

            // Image Upload
            if(Input::hasFile('post')){
                $filename = 'post_'.$date->getTimestamp(). '.' .
                    Input::file('post')->getClientOriginalExtension();

                Input::file('post')->move(
                    base_path() . '/public/images/blog/', $filename
                );
                $post->image = $filename;
            }

            $post->save();

            // Tag Process
            $tags = explode(',', Input::get('tags'));
            foreach($tags as $tag){
                $tagObj = Tag::where('name', $tag)->first();
                if(!$tagObj){
                    $insertTag = Tag::create(['name'=>$tag]);
                    PostTag::create(['post_id'=>$post->id, 'tag_id'=>$insertTag->id]);
                }else{
                    PostTag::create(['post_id'=>$post->id, 'tag_id'=>$tagObj->id]);
                }
            }

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updatePost($id){
        $rules = array(
            'content' => 'required',
            'title' =>'required',
            'category_id' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $post = Post::find($id);
            $post->title = Input::get('title');
            $post->content = Input::get('content');
            $post->author = Session::get('user')->id;
            $post->category_id = Input::get('category_id');
            $post->comments = 0;
            $post->status = 0;
            $post->date = date('Y-m-d H:i:s');

            if(Input::hasFile('post')){
                $filename = 'post_'.$date->getTimestamp(). '.' .
                    Input::file('post')->getClientOriginalExtension();

                Input::file('post')->move(
                    base_path() . '/public/images/blog/', $filename
                );
                $post->image = $filename;
            }

            $post->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function deletePost($id){
        Post::destroy($id);
        PostComment::where('post_id', $id)->delete();
        return Redirect::back()->with('message', "It has been updated successfully.");
    }
    public function createComment(){
        $rules = array(
            'content' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $comment = new PostComment();
            $comment->post_id = Input::get('id');
            $comment->user_id = Session::get('user')->id;
            $comment->content = Input::get('content');
            $comment->date = date('Y-m-d H:i:s');
            $comment->save();

            $post = Post::find(Input::get('id'));
            $post->comments = $post->comments + 1;
            $post->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function createReply(){
        $rules = array(
            'content' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $comment = new PostComment();
            $comment->post_id = Input::get('post_id');
            $comment->user_id = Session::get('user')->id;
            $comment->content = Input::get('content');
            $comment->date = date('Y-m-d H:i:s');
            $comment->comment_id = Input::get('comment_id');
            $comment->save();

            $post = Post::find(Input::get('post_id'));
            $post->comments = $post->comments + 1;
            $post->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getPostForFront($id){
        $post = Post::find($id);
        $categories = PostCategory::all();
        $events = OurEvent::take(3)->get();
        $relatedPosts = Post::where('category_id', $post->id)->limit(2)->get();
        $popularPosts = Post::orderBy('comments', 'desc')->limit(3)->get();
        $comments = PostComment::where('post_id', $id)->where('comment_id', 0)->get();
        $ad = Advertisement::where('page', 'post')->first();
        $flag = "blog";
        return View::make('pages.frontend.post', compact('flag', 'post', 'relatedPosts', 'categories', 'popularPosts', 'events', 'comments', 'ad'));
    }
    public function getPostListForFront(){
        $categories = PostCategory::all();
        $popularPosts = Post::orderBy('comments', 'desc')->limit(3)->get();
        $posts = Post::paginate(7);
        $flag = "blog";
        $ad = Advertisement::where('page', 'blog')->first();
        return View::make('pages.frontend.blog', compact('flag', 'categories', 'posts', 'popularPosts', 'ad'));
    }
    public function getSearchResult(){
        $categories = PostCategory::all();
        $popularPosts = Post::orderBy('comments', 'desc')->limit(3)->get();
        $posts = Post::where('title', 'LIKE', '%'.Input::get('keyword').'%')->orWhere('content', 'LIKE', '%'.Input::get('keyword').'%')->paginate(7);
        $flag = "blog";
        return View::make('pages.frontend.blog', compact('flag', 'categories', 'posts', 'popularPosts'));
    }
    public function getPostByCategoryForFront($id){
        $categories = PostCategory::all();
        $popularPosts = Post::orderBy('comments', 'desc')->limit(3)->get();
        if($id == 0){
            $posts = Post::paginate(7);
        }else{
            $posts = Post::where('category_id', $id)->paginate(7);
        }
        $flag = "blog";
        return View::make('pages.frontend.blog', compact('flag', 'categories', 'posts', 'popularPosts'));
    }
}
