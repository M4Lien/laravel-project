<?php

namespace App\Http\Controllers;
use App\Testimonial;
use App\Place;
use App\Curriculum;
use App\OurEvent;
use App\Advertisement;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class NurseryController extends BaseController
{
    public function getNurseriesForFront(){
        $testimonials = Testimonial::take(9)->get();
        $nurseries = Place::where('isNursery', 1)->paginate(6);
        $curriculum = Curriculum::all();
        $flag = "nurseries";
        return view('pages.frontend.nurseries', compact('flag', 'curriculum', 'testimonials', 'nurseries'));
    }
    public function getNurseryForFront($id){
        $nursery = Place::find($id);
        $curriculum = Curriculum::all();
        $relatedNurseries = Place::where('isNursery', 1)->where('curriculum_id', $nursery->curriculum_id)->get()->except($nursery->id);
        $events = OurEvent::take(3)->get();
        $ad = Advertisement::where('page', 'nursery')->first();
        $flag = "nurseries";
        return view('pages.frontend.nursery', compact('flag', 'curriculum', 'testimonials', 'nursery', 'relatedNurseries', 'events', 'ad'));
    }
    public function getNurseries(){
        $flag = "nurseriesList";
        $nurseries = Place::where('isNursery', 1)->get();
        return view('pages.backend.nursery.list', compact('flag', 'nurseries'));
    }
    public function createNursery(){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'curriculum_id' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $nursery = new Place();
            $nursery->name = Input::get('name');
            $nursery->curriculum_id = Input::get('curriculum_id');
            $nursery->min_age = Input::get('min_age');
            $nursery->max_age = Input::get('max_age');
            $nursery->description = Input::get('description');
            if(Input::has('phone')){
                $nursery->phone = Input::get('phone');
            }
            if(Input::has('site_address')){
                $nursery->site_address = Input::get('site_address');
            }
            if(Input::has('admission')){
                $nursery->admission = Input::get('admission');
            }
            if(Input::has('fee')){
                $nursery->fee = Input::get('fee');
            }
            $nursery->location = Input::get('location');
            $nursery->isSchool = 0;
            $nursery->isNursery = 1;

            if(Input::hasFile('nursery')){
                $filename = 'nursery_'.$date->getTimestamp(). '.' .
                    Input::file('nursery')->getClientOriginalExtension();

                Input::file('nursery')->move(
                    base_path() . '/public/images/nursery/', $filename
                );
                $nursery->logo = $filename;
            }

            $nursery->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getNurseryAddPage(){
        $isEdit = false;
        $curriculums = Curriculum::all();
        $flag = "nurseryAdd";
        return view('pages.backend.nursery.add', compact('flag', 'curriculums', 'isEdit'));
    }
    public function getNurseryEditPage($id){
        $isEdit = true;
        $curriculums = Curriculum::all();
        $nursery = Place::find($id);
        $flag = "nurseryAdd";
        return view('pages.backend.nursery.add', compact('flag', 'curriculums', 'nursery', 'isEdit'));
    }
    public function updateNursery($id){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'curriculum_id' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $nursery = Place::find($id);
            $nursery->name = Input::get('name');
            $nursery->curriculum_id = Input::get('curriculum_id');
            $nursery->min_age = Input::get('min_age');
            $nursery->max_age = Input::get('max_age');
            $nursery->description = Input::get('description');
            if(Input::has('phone')){
                $nursery->phone = Input::get('phone');
            }
            if(Input::has('site_address')){
                $nursery->site_address = Input::get('site_address');
            }
            if(Input::has('admission')){
                $nursery->admission = Input::get('admission');
            }
            if(Input::has('fee')){
                $nursery->fee = Input::get('fee');
            }
            $nursery->location = Input::get('location');
            $nursery->isSchool = 0;
            $nursery->isNursery = 1;

            if(Input::hasFile('nursery')){
                $filename = 'nursery_'.$date->getTimestamp(). '.' .
                    Input::file('nursery')->getClientOriginalExtension();

                Input::file('nursery')->move(
                    base_path() . '/public/images/nursery/', $filename
                );
                $nursery->logo = $filename;
            }

            $nursery->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function deleteNursery($id){
        Place::destroy($id);
        return Redirect::back()->with('message', "It has been deleted successfully.");
    }
}
