<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use App\User;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;

class AuthController extends BaseController
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }
    public function login(){
        Session::forget('user');
        $user = User::where('email', Input::get('email'))->where('password', hash('md5',Input::get('password')))->first();
        if(isset($user)) {
            Session::put('user',$user);
            if($user->status != 0){
                if(Input::get('redirect') == 1){
                    return Redirect::to('admin');
                }else {
                    return Redirect::back();
                }
            }else{
                return Redirect::back()->withErrors('You have to confirm e-mail.');
            }
        }else{
            return Redirect::back()->withErrors('These credentials do not match our records.');
        }
    }
    public function postRegister(){
        $validator = Validator::make(Input::all(), User::$rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator)->withInput();
        }else{
            $code = str_random(60);
            User::create(array_merge(
                Input::except('password', '_token', 'first_name', 'last_name'),
                ['full_name' => Input::get('first_name').' '.Input::get('last_name')],
                ['status' => 0],
                ['role_id' => 5],
                ['password' => hash('md5', Input::get('password'))],
                ['code' => $code]
            ));
            $user_email = Input::get('email');
            $data = [
                'code'=>$code
            ];
            Mail::send('emails.register', compact('data'), function($message) use ($user_email)
            {
                $message->from('contact@schoolistan.pk', 'contact');
                $message->to('silverelib_318@yahoo.com', 'silver')->subject('Please activate your account.');
            });

            return Redirect::back()->with('message', "You've been registered at this site successfully.");
        }
    }
    public function logout(){
        Session::forget('user');
        return Redirect::to('/');
    }
    public function activateAccount($code){
        $user = User::where('code', $code)->first();
        if($user){
            $user->status = 1;
            $user->save();
            return 'success';
        }else {
            return 'failure';
        }
    }
}
