<?php

namespace App\Http\Controllers;
use App\ActivityCategory;
use App\Institute;
use App\Activity;
use Illuminate\Support\Facades\View;
use App\Category;
use App\ActivityReview;
use App\OurEvent;
use App\Advertisement;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class InstituteController extends BaseController
{
    public function getInstitutesForFront(){
        $categories = ActivityCategory::all();
        $institutes = Institute::paginate(6);

        $activities = Activity::take(3)->get();
        $flag = "institutes";
        return View::make('pages.frontend.institutes', compact('flag', 'categories', 'activities', 'institutes'));
    }

    public function getInstitutes(){
        $institutes = Institute::all();
        $flag = "institutesList";
        return View::make('pages.backend.institute.list', compact('flag', 'institutes'));
    }
    public function getInstituteAddPage(){
        $isEdit = false;
        $flag = "instituteAdd";
        $activities = Activity::all();
        $categories = Category::all();
        return View::make('pages.backend.institute.add', compact('flag', 'categories', 'activities', 'isEdit'));
    }
    public function getInstituteEditPage($id){
        $institute = Institute::find($id);
        $isEdit = true;
        $flag = "instituteAdd";
        $activities = Activity::all();
        $categories = Category::all();
        return View::make('pages.backend.institute.add', compact('flag', 'categories', 'activities', 'institute', 'isEdit'));
    }
    public function getInstituteForFront($id){
        $institute = Institute::find($id);
        $reviews = ActivityReview::where('activity_id', $id)->get();
        $events = OurEvent::take(3)->get();
        $relatedInstitutes = Institute::where('category_id', $institute->category_id)->get()->except($institute->id);
        $categories = ActivityCategory::all();
        $ad = Advertisement::where('page', 'institute')->first();
        $flag = "institutes";
        return View::make('pages.frontend.institute', compact('flag', 'institute', 'events', 'relatedInstitutes', 'categories', 'reviews', 'ad'));
    }
    public function createInstitute(){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'category' => 'required|numeric',
            'activity' => 'required|numeric',
            'min_price' => 'required|numeric',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $institute = new Institute();
            $institute->name = Input::get('name');
            $institute->description = Input::get('description');
            $institute->min_age = Input::get('min_age');
            $institute->max_age = Input::get('max_age');
            $institute->category_id = Input::get('category');
            $institute->activity_id = Input::get('activity');
            $institute->min_price = Input::get('min_price');
            if(Input::has('location')){
                $institute->location = Input::get('location');
            }
            if(Input::has('phone')){
                $institute->phone = Input::get('phone');
            }
            if(Input::has('site_address')){
                $institute->site_address = Input::get('site_address');
            }
            if(Input::has('isSpecialOffer')){
                $institute->isSpecialOffer = 1;
            }
            if(Input::hasFile('institute')){
                $filename = 'institute_'.$date->getTimestamp(). '.' .
                    Input::file('institute')->getClientOriginalExtension();

                Input::file('institute')->move(
                    base_path() . '/public/images/institute/', $filename
                );
                $institute->logo = $filename;
            }

            $institute->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateInstitute($id){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'category' => 'required|numeric',
            'activity' => 'required|numeric',
            'min_price' => 'required|numeric',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $institute = Institute::find($id);
            $institute->name = Input::get('name');
            $institute->description = Input::get('description');
            $institute->min_age = Input::get('min_age');
            $institute->max_age = Input::get('max_age');
            $institute->category_id = Input::get('category');
            $institute->activity_id = Input::get('activity');
            $institute->min_price = Input::get('min_price');
            if(Input::has('location')){
                $institute->location = Input::get('location');
            }
            if(Input::has('phone')){
                $institute->phone = Input::get('phone');
            }
            if(Input::has('site_address')){
                $institute->site_address = Input::get('site_address');
            }
            if(Input::has('isSpecialOffer')){
                $institute->isSpecialOffer = 1;
            }
            if(Input::hasFile('institute')){
                $filename = 'institute_'.$date->getTimestamp(). '.' .
                    Input::file('institute')->getClientOriginalExtension();

                Input::file('institute')->move(
                    base_path() . '/public/images/institute/', $filename
                );
                $institute->logo = $filename;
            }

            $institute->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function createReview(){
        $rules = array(
            'content' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $activity = new ActivityReview();
            $activity->content = Input::get('content');
            $activity->user_id = Session::get('user')->id;
            $activity->activity_id = Input::get('activity_id');
            $activity->date = date('Y-m-d H:i:s');
            $activity->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function deleteInstitute($id){
        Institute::destroy($id);
        return Redirect::back()->with('message', "It has been deleted successfully.");
    }
}
