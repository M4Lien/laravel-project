<?php

namespace App\Http\Controllers;
use App\ActivityCategory;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Category;
use App\Activity;

class CategoryController extends BaseController
{
    public function getCategoryList(){
        $flag = "categoryList";
        $categories = ActivityCategory::all();
        return View::make('pages.backend.category.list', compact('flag', 'categories'));
    }
    public function getCategoryAdd(){
        $isEdit = false;
        $flag = "categoryAdd";
        return View::make('pages.backend.category.add', compact('flag', 'isEdit'));
    }
    public function postCategoryAdd(){
        $rules = array(
            'name' => 'required',
            'description' => 'required',
            'icon' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $category = new ActivityCategory();
            $category->name = Input::get('name');
            $category->description = Input::get('description');
            $category->icon = Input::get('icon');
            $category->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateCategory($id){
        $rules = array(
            'name' => 'required',
            'description' => 'required',
            'icon' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $category = ActivityCategory::find($id);
            $category->name = Input::get('name');
            $category->description = Input::get('description');
            $category->icon = Input::get('icon');
            $category->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getCategoryEdit($id){
        $flag = "categoryAdd";
        $isEdit = true;
        $category = Category::find($id);
        return View::make('pages.backend.category.add', compact('flag', 'category', 'isEdit'));
    }
    public function deleteCategory($id){
        $activity = Activity::where('category_id', $id)->get();
        if($activity->count() == 0){
            ActivityCategory::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. There are activities associated with this category.");
        }
    }
    public function showHome($id){
        $category = ActivityCategory::find($id);
        if($category->IsHomeShow == 1){
            $category->IsHomeShow = 0;
        }else{
            $category->IsHomeShow = 1;
        }
        $category->save();
        return Redirect::back()->with('message', "It has been set successfully.");
    }
}
