<?php

namespace App\Http\Controllers;
use App\Facility;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Activity;

class FacilityController extends BaseController
{
    public function getFacilityList(){
        $flag = "facilityList";
        $facilities = Facility::all();
        return View::make('pages.backend.facility.list', compact('flag', 'facilities'));
    }
    public function getFacilityAdd(){
        $isEdit = false;
        $flag = "facilityAdd";
        return View::make('pages.backend.facility.add', compact('flag', 'isEdit'));
    }
    public function postFacilityAdd(){
        $rules = array(
            'name' => 'required',
            'description' => 'required',
            'icon' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $facility = new Facility();
            $facility->name = Input::get('name');
            $facility->description = Input::get('description');
            $facility->icon = Input::get('icon');
            $facility->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateFacility($id){
        $rules = array(
            'name' => 'required',
            'description' => 'required',
            'icon' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $facility = Facility::find($id);
            $facility->name = Input::get('name');
            $facility->description = Input::get('description');
            $facility->icon = Input::get('icon');
            $facility->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getFacilityEdit($id){
        $flag = "facilityAdd";
        $isEdit = true;
        $facility = Facility::find($id);
        return View::make('pages.backend.facility.add', compact('flag', 'facility', 'isEdit'));
    }
    public function deleteFacility($id){
        $activity = Activity::where('category_id', $id)->get();
        if($activity->count() == 0){
            Facility::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. There are activities associated with this facility.");
        }
    }
}
