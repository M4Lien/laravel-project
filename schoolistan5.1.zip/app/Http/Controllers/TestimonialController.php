<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\View;
use App\Testimonial;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class TestimonialController extends BaseController
{
    public function getTestimonialAdd(){
        $isEdit = false;
        $flag = "testimonialAdd";
        return View::make('pages.backend.page.testimonial.add', compact('flag', 'isEdit'));
    }
    public function getTestimonialList(){
        $testimonials = Testimonial::all();
        $flag = "testimonialsList";
        return View::make('pages.backend.page.testimonial.list', compact('flag', 'testimonials'));
    }
    public function postTestimonialAdd(){
        $testimonial = new Testimonial();
        $testimonial->name = Input::get('name');
        $testimonial->content = Input::get('content');
        if(Input::hasFile('image')){
            $date = new DateTime();
            $filename = 'testimonial_'.$date->getTimestamp(). '.' .
                Input::file('image')->getClientOriginalExtension();

            Input::file('image')->move(
                base_path() . '/public/images/testimonial/', $filename
            );
            $testimonial->avatar = $filename;
        }
        $testimonial->save();
        return Redirect::back()->with('message', 'It has been registered successfully.');
    }
    public function getTestimonialEdit($id){
        $testimonial = Testimonial::find($id);
        $isEdit = true;
        $flag = "testimonialAdd";
        return View::make('pages.backend.page.testimonial.add', compact('flag', 'testimonial', 'isEdit'));
    }
    public function updateTestimonial($id){
        $testimonial = Testimonial::find($id);
        $testimonial->name = Input::get('name');
        $testimonial->content = Input::get('content');
        if(Input::hasFile('image')){
            $date = new DateTime();
            $filename = 'testimonial_'.$date->getTimestamp(). '.' .
                Input::file('image')->getClientOriginalExtension();

            Input::file('image')->move(
                base_path() . '/public/images/testimonial/', $filename
            );
            $testimonial->avatar = $filename;
        }
        $testimonial->save();
        return Redirect::back()->with('message', 'It has been updated successfully.');
    }
    public function deleteTestimonial($id){
        Testimonial::destroy($id);
        return Redirect::back()->with('message', 'It has been deleted successfully.');
    }
}
