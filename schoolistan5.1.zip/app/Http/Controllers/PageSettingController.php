<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use App\PageSetting;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class PageSettingController extends BaseController
{
    public function getHome(){
        $pages = PageSetting::where('type', 'home')->get();
        $items = [];
        foreach($pages as $page){
            $items[$page->property] = $page->value;
        }
        $flag = "homeAdd";
        return View::make('pages.backend.page.home', compact('flag', 'items'));
    }
    public function postHome(){
        $namespace = ['slider1', 'slider2', 'slider3', 'schools', 'nurseries', 'institutes'];
        foreach($namespace as $name){
            if(Input::hasFile($name)){
                $date = new DateTime();
                $filename = 'home_'.$name.'_'.$date->getTimestamp(). '.' .
                    Input::file($name)->getClientOriginalExtension();

                Input::file($name)->move(
                    base_path() . '/public/images/', $filename
                );
                $record = PageSetting::where('type', 'home')->where('property', $name.'_image')->first();
                if(!$record){
                    $page = new PageSetting();
                    $page->type = 'home';
                    $page->property = $name.'_image';
                    $page->value = $filename;
                    $page->save();
                }else{
                    $record->value = $filename;
                    $record->save();
                }
            }
            if(Input::has($name.'_title')){
                $record = PageSetting::where('type', 'home')->where('property', $name.'_title')->first();
                if(!$record){
                    $page = new PageSetting();
                    $page->type = 'home';
                    $page->property = $name.'_title';
                    $page->value = Input::get($name.'_title');
                    $page->save();
                }else{
                    $record->value = Input::get($name.'_title');
                    $record->save();
                }
            }
            if(Input::has($name.'_description')){
                $record = PageSetting::where('type', 'home')->where('property', $name.'_description')->first();
                if(!$record){
                    $page = new PageSetting();
                    $page->type = 'home';
                    $page->property = $name.'_description';
                    $page->value = Input::get($name.'_description');
                    $page->save();
                }else{
                    $record->value = Input::get($name.'_description');
                    $record->save();
                }
            }
        }

        return Redirect::back()->with('message', 'It has been registered successfully.');
    }
    public function getAbout(){
        $flag = "aboutAdd";
        $pages = PageSetting::where('type', 'about')->get();
        $items = [];
        foreach($pages as $page){
            $items[$page->property] = $page->value;
        }
        return View::make('pages.backend.page.about', compact('flag', 'items'));
    }
    public function postAbout(){
        $namespace = ['intro', 'mission', 'vision', 'goal'];
        foreach($namespace as $name){
            if(Input::hasFile($name)){
                $date = new DateTime();
                $filename = 'about_'.$name.'_'.$date->getTimestamp(). '.' .
                    Input::file($name)->getClientOriginalExtension();

                Input::file($name)->move(
                    base_path() . '/public/images/', $filename
                );
                $record = PageSetting::where('type', 'about')->where('property', $name.'_image')->first();
                if(!$record){
                    $page = new PageSetting();
                    $page->type = 'about';
                    $page->property = $name.'_image';
                    $page->value = $filename;
                    $page->save();
                }else{
                    $record->value = $filename;
                    $record->save();
                }
            }
            if(Input::has($name.'_title')){
                $record = PageSetting::where('type', 'about')->where('property', $name.'_title')->first();
                if(!$record){
                    $page = new PageSetting();
                    $page->type = 'about';
                    $page->property = $name.'_title';
                    $page->value = Input::get($name.'_title');
                    $page->save();
                }else{
                    $record->value = Input::get($name.'_title');
                    $record->save();
                }
            }
            if(Input::has($name.'_description')){
                $record = PageSetting::where('type', 'about')->where('property', $name.'_description')->first();
                if(!$record){
                    $page = new PageSetting();
                    $page->type = 'about';
                    $page->property = $name.'_description';
                    $page->value = Input::get($name.'_description');
                    $page->save();
                }else{
                    $record->value = Input::get($name.'_description');
                    $record->save();
                }
            }
        }
        return Redirect::back()->with('message', 'It has been registered successfully.');
    }
}
