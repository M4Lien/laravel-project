<?php

namespace App\Http\Controllers;

use App\OurEvent;
use Illuminate\Support\Facades\View;
use App\EventCategory;
use App\Gallery;
use App\GalleryImage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;

class EventController extends BaseController
{
    public function getEventList(){
        $flag = "eventsList";
        $events = OurEvent::all();
        return View::make('pages.backend.event.list', compact('flag', 'events'));
    }
    public function getEventAddPage(){
        $isEdit = false;
        $categories = EventCategory::all();
        $flag = "eventAdd";
        return View::make('pages.backend.event.add', compact('flag', 'categories', 'isEdit'));
    }
    public function getEventEditPage($id){
        $isEdit = true;
        $categories = EventCategory::all();
        $event = OurEvent::find($id);
        $flag = "eventAdd";
        return View::make('pages.backend.event.add', compact('flag', 'categories', 'isEdit', 'event'));
    }
    public function getGalleryList(){
        $galleries = Gallery::all();
        $flag = "galleryList";
        return View::make('pages.backend.event.gallery_list', compact('flag', 'galleries'));
    }
    public function getGalleryAddPage(){
        $isEdit = false;
        $ourEvents = OurEvent::all();
        $events = [];
        foreach($ourEvents as $event){
            if(Gallery::where('event_id', $event->id)->get()->count() == 0){
                array_push($events, $event);
            }
        }

        $flag = "galleryAdd";
        return View::make('pages.backend.event.gallery_add', compact('flag', 'events', 'isEdit'));
    }
    public function getGalleryEditPage($id){
        $isEdit = true;
        $gallery = Gallery::find($id);
        $event = OurEvent::find($gallery->event_id);
        $images = GalleryImage::where('gallery_id', $gallery->id)->get();
        $ourEvents = OurEvent::all();
        $events = [];
        foreach($ourEvents as $event){
            if(Gallery::where('event_id', $event->id)->get()->count() == 0){
                array_push($events, $event);
            }
        }

        $flag = "galleryAdd";
        return View::make('pages.backend.event.gallery_add', compact('flag', 'events', 'event', 'isEdit', 'images', 'gallery'));
    }
    public function postEvent(){
        $rules = array(
            'name' => 'required',
            'description' => 'required',
            'min_time' => 'required',
            'max_time' => 'required',
            'category_id' => 'required',
            'date' => 'required',
            'cost' => 'required',
            'tag' =>'required',
            'venue_name' => 'required',
            'venue_phone' => 'required',
            'venue_lat' => 'required',
            'venue_lng' => 'required',
            'venue_address' => 'required',
            'organizer_name' => 'required',
            'organizer_phone' => 'required',
            'organizer_email' => 'required|email',
            'organizer_site' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $event = new OurEvent();
            $event->name = Input::get('name');
            $event->description = Input::get('description');
            $event->category_id = Input::get('category_id');
            $event->min_time = date('h:i', strtotime(Input::get('min_time')));
            $event->max_time = date('h:i', strtotime(Input::get('max_time')));
            $event->cost = Input::get('cost');
            $event->tag = Input::get('tag');
            $event->date = date('Y-m-d', strtotime(Input::get('date')));
            $event->user_id = Session::get('user')->id;
            $event->organizer_name = Input::get('organizer_name');
            $event->organizer_phone = Input::get('organizer_phone');
            $event->organizer_email = Input::get('organizer_email');
            $event->organizer_site = Input::get('organizer_site');
            $event->venue_address = Input::get('venue_address');
            $event->venue_name = Input::get('venue_name');
            $event->venue_phone = Input::get('venue_phone');
            $event->venue_lat = Input::get('venue_lat');
            $event->venue_lng = Input::get('venue_lng');
            if(Input::hasFile('event')){
                $filename = 'event_'.$date->getTimestamp(). '.' .
                    Input::file('event')->getClientOriginalExtension();

                Input::file('event')->move(
                    base_path() . '/public/images/event/', $filename
                );
                $event->logo = $filename;
            }

            $event->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateEvent($id){
        $rules = array(
            'name' => 'required',
            'description' => 'required',
            'min_time' => 'required',
            'max_time' => 'required',
            'category_id' => 'required',
            'date' => 'required',
            'cost' => 'required',
            'tag' =>'required',
            'venue_name' => 'required',
            'venue_phone' => 'required',
            'venue_lat' => 'required',
            'venue_lng' => 'required',
            'venue_address' => 'required',
            'organizer_name' => 'required',
            'organizer_phone' => 'required',
            'organizer_email' => 'required|email',
            'organizer_site' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $event = OurEvent::find($id);
            $event->name = Input::get('name');
            $event->description = Input::get('description');
            $event->category_id = Input::get('category_id');
            $event->min_time = date('h:i', strtotime(Input::get('min_time')));
            $event->max_time = date('h:i', strtotime(Input::get('max_time')));
            $event->cost = Input::get('cost');
            $event->tag = Input::get('tag');
            $event->date = date('Y-m-d', strtotime(Input::get('date')));
            $event->user_id = Session::get('user')->id;
            $event->organizer_name = Input::get('organizer_name');
            $event->organizer_phone = Input::get('organizer_phone');
            $event->organizer_email = Input::get('organizer_email');
            $event->organizer_site = Input::get('organizer_site');
            $event->venue_address = Input::get('venue_address');
            $event->venue_name = Input::get('venue_name');
            $event->venue_phone = Input::get('venue_phone');
            $event->venue_lat = Input::get('venue_lat');
            $event->venue_lng = Input::get('venue_lng');
            if(Input::hasFile('event')){
                $filename = 'event_'.$date->getTimestamp(). '.' .
                    Input::file('event')->getClientOriginalExtension();

                Input::file('event')->move(
                    base_path() . '/public/images/event/', $filename
                );
                $event->logo = $filename;
            }

            $event->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }

    public function getEventsForFront(){
        $current = date('Y-m-d');
        $current_from = date('Y-m-01', strtotime($current));
        $current_end = date("Y-m-t", strtotime($current_from));
        $next = date('Y-m-d', strtotime('+1 month', strtotime($current_from)));
        $next_from = date('Y-m-01', strtotime($next));
        $next_end = date('Y-m-t', strtotime($next));
        $currentEvents = OurEvent::where('date', '>=', $current)->where('date', '<=', $current_end)->get();
        $nextEvents = OurEvent::where('date', '>=', $next_from)->where('date', '<=', $next_end)->get();
        $flag = "events";
        $search = 0;
        return View::make('pages.frontend.upcoming_events', compact('flag', 'currentEvents', 'nextEvents', 'current_from', 'next_from', 'search'));
    }
    public function showGallery($id){
        $gallery = Gallery::where('event_id', $id)->first();
        if($gallery){
            $images = GalleryImage::where('gallery_id', $gallery->id)->get();
        }else{
            $images = [];
        }
        $flag = "events";
        return View::make('pages.frontend.events_gallery', compact('flag', 'gallery', 'images'));
    }
    public function getEventForFront($id){
        $event = OurEvent::find($id);
        $relatedEvents = OurEvent::where('category_id', $event->category_id)->limit(3)->get()->except($event->id);
        $previous = OurEvent::where('id', '<', $event->id)->max('id');
        if(!$previous){
            $previous = 0;
        }
        $next = OurEvent::where('id', '>', $event->id)->min('id');
        if(!$next){
            $next = 0;
        }
        $flag = "events";
        return View::make('pages.frontend.event', compact('flag', 'event', 'relatedEvents', 'next', 'previous'));
    }
    public function getSearchResult($fromDate, $keyword){
        $current = date('Y-m-d', strtotime($fromDate));
        $currentEvents = OurEvent::where('date', '>=', $current)->where('name', 'LIKE', '%'.$keyword.'%')->orderBy('date', 'asc')->paginate(5);

        $search = 1;
        $flag = "events";
        return View::make('pages.frontend.upcoming_events', compact('flag', 'currentEvents', 'current', 'search'));
    }
    public function getSearchResultWithoutKey($fromDate){
        $current = date('Y-m-d', strtotime($fromDate));
        $currentEvents = OurEvent::where('date', '>=', $current)->orderBy('date', 'asc')->paginate(5);

        $search = 1;
        $flag = "events";
        return View::make('pages.frontend.upcoming_events', compact('flag', 'currentEvents', 'current', 'search'));
    }
    public function getSearchResultForNow($now){
        if($now == 'Month'){
            $current = date('Y-m-d');
            $current_from = date('Y-m-01', strtotime($current));
            $current_end = date("Y-m-t", strtotime($current_from));
            $currentEvents = OurEvent::where('date', '>=', $current_from)->where('date', '<=', $current_end)->orderBy('date', 'asc')->paginate(5);
        } else if($now == 'Day') {
            $current = date('Y-m-d', strtotime(date('Y-m-d')));
            $currentEvents = OurEvent::where('date', $current)->orderBy('date', 'asc')->paginate(5);
        } else {
            $day = date('w');
            $current_from = date('Y-m-d', strtotime('-'.$day.' days'));
            $current_end = date('Y-m-d', strtotime('+'.(6-$day).' days'));
            $currentEvents = OurEvent::where('date', '>=', $current_from)->where('date', '<=', $current_end)->orderBy('date', 'asc')->paginate(5);
        }

        $search = 2;
        $flag = "events";
        return View::make('pages.frontend.upcoming_events', compact('flag', 'currentEvents', 'now', 'search'));
    }
    public function imageUpload(){
        $input = Input::all();
        $gallery = Gallery::where('event_id', Input::get('event_id'))->first();
        if(!$gallery){
            $gallery = Gallery::create([
                'name' => Input::get('name'),
                'description' => Input::get('description'),
                'event_id' => Input::get('event_id'),
            ]);
        }

        $rules = array(
            'file' => 'image|max:3000',
        );

        $validation = Validator::make($input, $rules);

        if ($validation->fails()) {
            return Response::make($validation->errors->first(), 400);
        }

        $destinationPath = 'images/gallery/'; // upload path
        $extension = Input::file('file')->getClientOriginalExtension(); // getting file extension
        $fileName = 'gallery_'.str_random(12) . '.' . $extension; // renameing image
        $upload_success = Input::file('file')->move($destinationPath, $fileName); // uploading file to given path

        if ($upload_success) {
            GalleryImage::create([
                'gallery_id' => $gallery->id,
                'image' => $fileName
            ]);
            return Response::json('success', 200);
        } else {
            return Response::json('error', 400);
        }
    }
    public function deleteGallery($id){
        $images = GalleryImage::where('gallery_id', $id)->get();
        if($images->count() == 0){
            Gallery::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. This gallery has one or more images.");
        }
    }
    public function deleteImage($id){
        GalleryImage::destroy($id);
        return Redirect::back();
    }
}
