<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use App\OurEvent;
use App\Advertisement;
use App\Testimonial;
use App\Place;
use App\Curriculum;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;


class SchoolController extends BaseController
{
    public function getSchoolsForFront(){
        $curriculum = Curriculum::all();
        $testimonials = Testimonial::take(9)->get();
        $schools = Place::where('isSchool', 1)->paginate(6);
        $flag = "schools";
        return View::make('pages.frontend.schools', compact('flag', 'curriculum', 'testimonials', 'schools'));
    }
    public function getSchoolForFront($id){
        $school = Place::find($id);
        $curriculum = Curriculum::all();
        $relatedSchools = Place::where('isSchool', 1)->where('curriculum_id', $school->curriculum_id)->get()->except($school->id);
        $events = OurEvent::take(3)->get();
        $ad = Advertisement::where('page', 'school')->first();
        $flag = "schools";
        return View::make('pages.frontend.school', compact('flag', 'curriculum', 'testimonials', 'school', 'relatedSchools', 'events', 'ad'));
    }
    public function getSchools(){
        $flag = "schoolsList";
        $schools = Place::where('isSchool', 1)->get();
        return View::make('pages.backend.school.list', compact('flag', 'schools'));
    }
    public function createSchool(){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'curriculum_id' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $school = new Place();
            $school->name = Input::get('name');
            $school->curriculum_id = Input::get('curriculum_id');
            $school->min_age = Input::get('min_age');
            $school->max_age = Input::get('max_age');
            $school->description = Input::get('description');
            if(Input::has('phone')){
                $school->phone = Input::get('phone');
            }
            if(Input::has('site_address')){
                $school->site_address = Input::get('site_address');
            }
            if(Input::has('admission')){
                $school->admission = Input::get('admission');
            }
            if(Input::has('fee')){
                $school->fee = Input::get('fee');
            }
            $school->location = Input::get('location');
            $school->isSchool = 1;
            $school->isNursery = 0;

            if(Input::hasFile('school')){
                $filename = 'school_'.$date->getTimestamp(). '.' .
                    Input::file('school')->getClientOriginalExtension();

                Input::file('school')->move(
                    base_path() . '/public/images/school/', $filename
                );
                $school->logo = $filename;
            }

            $school->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getSchoolAddPage(){
        $isEdit = false;
        $curriculums = Curriculum::all();
        $flag = "schoolAdd";
        return View::make('pages.backend.school.add', compact('flag', 'curriculums', 'isEdit'));
    }
    public function getSchoolEditPage($id){
        $school = Place::find($id);
        $isEdit = true;
        $curriculums = Curriculum::all();
        $flag = "schoolAdd";
        return View::make('pages.backend.school.add', compact('flag', 'curriculums', 'isEdit', 'school'));
    }
    public function updateSchool($id){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'curriculum_id' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $school = Place::find($id);
            $school->name = Input::get('name');
            $school->curriculum_id = Input::get('curriculum_id');
            $school->min_age = Input::get('min_age');
            $school->max_age = Input::get('max_age');
            $school->description = Input::get('description');
            if(Input::has('phone')){
                $school->phone = Input::get('phone');
            }
            if(Input::has('site_address')){
                $school->site_address = Input::get('site_address');
            }
            if(Input::has('admission')){
                $school->admission = Input::get('admission');
            }
            if(Input::has('fee')){
                $school->fee = Input::get('fee');
            }
            $school->location = Input::get('location');
            $school->isSchool = 1;
            $school->isNursery = 0;

            if(Input::hasFile('school')){
                $filename = 'school_'.$date->getTimestamp(). '.' .
                    Input::file('school')->getClientOriginalExtension();

                Input::file('school')->move(
                    base_path() . '/public/images/school/', $filename
                );
                $school->logo = $filename;
            }

            $school->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function deleteSchool($id){
        Place::destroy($id);
        return Redirect::back()->with('message', "It has been deleted successfully.");
    }
}
