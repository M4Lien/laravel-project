<?php

namespace App\Http\Controllers;
use App\Activity;
use App\ActivityCategory;
use App\Testimonial;
use App\Institute;
use App\OurEvent;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\View;

class ActivityController extends BaseController
{
    public function getActivities(){
        $activities = Activity::all();
        $flag = "activitiesList";
        return View::make('pages.backend.activity.list', compact('flag', 'activities'));
    }
    public function getActivitiesForFront($categoryName){
        $flag = "activities";
        if($categoryName == 'all'){
            $activities = Activity::paginate(6);
        }else {
            $categoryObj = ActivityCategory::where('name', $categoryName)->first();
            $activities = Activity::where('category_id', $categoryObj->id)->paginate('6');
        }
        $categories = ActivityCategory::all();
        $testimonials = Testimonial::all();
        return View::make('pages.frontend.activities', compact('flag', 'activities', 'categories', 'testimonials', 'categoryName'));
    }
    public function getActivityForFront($id){
        $flag = "activities";
        $activity = Activity::find($id);
        $categories = ActivityCategory::all();
        $institute = Institute::find($activity->institute_id);
        $events = OurEvent::take(4)->get();
        return View::make('pages.frontend.activity', compact('flag', 'activity', 'categories', 'events', 'institute'));
    }
    public function getActivityAddPage(){
        $isEdit = false;
        $flag = "activityAdd";
        $institutes = Institute::all();
        return View::make('pages.backend.activity.add', compact('flag', 'isEdit', 'institutes'));
    }
    public function getActivityEditPage($id){
        $flag = "activityAdd";
        $isEdit = true;
        $activity = Activity::find($id);
        $institutes = Institute::all();
        return View::make('pages.backend.activity.add', compact('flag', 'activity', 'isEdit', 'institutes'));
    }
    public function createActivity(){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'activity' => 'required',
            'institute_id' =>'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $activity = new Activity();
            $activity->name = Input::get('name');
            $activity->description = Input::get('description');
            $activity->institute_id = Input::get('institute_id');

            if(Input::hasFile('activity')){
                $filename = 'activity_'.$date->getTimestamp(). '.' .
                    Input::file('activity')->getClientOriginalExtension();

                Input::file('activity')->move(
                    base_path() . '/public/images/activity/', $filename
                );
                $activity->logo = $filename;
            }

            $activity->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateActivity($id){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
            'institute_id' =>'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $activity = Activity::find($id);
            $activity->name = Input::get('name');
            $activity->description = Input::get('description');
            $activity->institute_id = Input::get('institute_id');

            if(Input::hasFile('activity')){
                $filename = 'activity_'.$date->getTimestamp(). '.' .
                    Input::file('activity')->getClientOriginalExtension();

                Input::file('activity')->move(
                    base_path() . '/public/images/activity/', $filename
                );
                $activity->logo = $filename;
            }

            $activity->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function deleteActivity($id){
        $places = Institute::where('activity_id', $id)->get();
        if($places->count() == 0){
            Activity::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. There are institutes associated with this activity.");
        }
    }
}
