<?php

namespace App\Http\Controllers;
use App\PageSetting;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;

class ContactController extends BaseController
{
    public function getContactBackendPage(){
        $flag = "contactsAdd";
        return View::make('pages.backend.page.contacts', compact('flag'));
    }
    public function postContactBackendPage(){
        $rules = array(
            'master_address' => 'required',
            'master_phone' => 'required',
            'master_fax' => 'required',
            'master_email' => 'required|email',
            'contact_address' => 'required',
            'contact_phone' => 'required',
            'contact_email' => 'required|email',
            'map_latitude' => 'required',
            'map_longitude' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $params = ['map_latitude', 'map_longitude', 'master_address', 'master_email', 'master_fax', 'master_phone', 'contact_address', 'contact_email', 'contact_phone'];
            foreach($params as $param){
                $page = PageSetting::where('type', 'contact')->where('property', $param)->first();
                if(!$page){
                    $page = new PageSetting();
                    $page->type = 'contact';
                    $page->property = $param;
                    $page->value = Input::get($param);
                    $page->save();
                }else{
                    $page->value = Input::get($param);
                    $page->save();
                }
            }
            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getContactPage(){
        $flag = "contact";
        return View::make('pages.frontend.contact', compact('flag'));
    }
    public function createContact(){
        $rules = array(
            'cf-name' => 'required',
            'cf-email' => 'required',
            'cf-message' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $contactName = Input::get('cf-name');
            $contactEmail = Input::get('cf-email');
            $contactMessage = Input::get('cf-message');
            $contactSubject = "";
            if(Input::has('cf-subject')){
                $contactSubject = Input::get('cf-subject');
            }

            $data = [
                'name'=>$contactName,
                'email'=>$contactEmail,
                'message'=>$contactMessage
            ];

            Mail::send('emails.contact', compact('data'), function($message) use ($contactEmail, $contactName, $contactSubject)
            {
                $message->from($contactEmail, $contactName);
                $message->to('contact@schoolistan.pk', 'contact')->subject($contactSubject);
            });


            $contact = new Contact();
            $contact->name = $contactName;
            $contact->email = $contactEmail;
            $contact->subject = $contactSubject;
            $contact->message = $contactMessage;
            $contact->date = date('Y-m-d H:i:s');
            $contact->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
}
