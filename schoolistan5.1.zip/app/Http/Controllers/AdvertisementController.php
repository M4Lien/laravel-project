<?php

namespace App\Http\Controllers;
use App\Advertisement;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

class AdvertisementController extends BaseController
{
    public function getAdvertises(){
        $advertises = Advertisement::all();
        $flag = "advertiseList";
        return View::make('pages.backend.cms.advertise.list', compact('flag', 'advertises'));
    }
    public function getAdvertiseAddPage(){
        $isEdit = false;
        $flag = "advertiseAdd";
        return View::make('pages.backend.cms.advertise.add', compact('flag', 'isEdit'));
    }
    public function getAdvertiseEditPage($id){
        $flag = "advertiseAdd";
        $isEdit = true;
        $advertise = Advertisement::find($id);
        return View::make('pages.backend.cms.advertise.add', compact('flag', 'advertise', 'isEdit'));
    }
    public function createAdvertise(){
        $rules = array(
            'title' => 'required',
            'content' =>'required',
            'link' => 'required',
            'page' => 'required',
            'position' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $advertise = new Advertisement();
            $advertise->title = Input::get('title');
            $advertise->content = Input::get('content');
            $advertise->link = Input::get('link');
            $advertise->page = Input::get('page');
            $advertise->position = Input::get('position');

            if(Input::hasFile('advertise')){
                $filename = 'advertise_'.$date->getTimestamp(). '.' .
                    Input::file('advertise')->getClientOriginalExtension();

                Input::file('advertise')->move(
                    base_path() . '/public/images/advertise/', $filename
                );
                $advertise->image = $filename;
            }

            $advertise->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateAdvertise($id){
        $rules = array(
            'title' => 'required',
            'content' =>'required',
            'link' => 'required',
            'page' => 'required',
            'position' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $date = new DateTime();
            $advertise = Advertisement::find($id);
            $advertise->title = Input::get('title');
            $advertise->content = Input::get('content');
            $advertise->link = Input::get('link');
            $advertise->page = Input::get('page');
            $advertise->position = Input::get('position');

            if(Input::hasFile('advertise')){
                $filename = 'advertise_'.$date->getTimestamp(). '.' .
                    Input::file('advertise')->getClientOriginalExtension();

                Input::file('advertise')->move(
                    base_path() . '/public/images/advertise/', $filename
                );
                $advertise->image = $filename;
            }

            $advertise->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function deleteAdvertise($id){
        Advertisement::destroy($id);
        return Redirect::back()->with('message', "It has been deleted successfully.");
    }
}
