<?php

namespace App\Http\Controllers;
use App\Faq;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class FaqController extends BaseController
{
    public function getFaqsForFront(){
        $faqs = Faq::where('isShow', 1)->get();
        $flag = "home";
        return View::make('pages.frontend.faqs', compact('flag', 'faqs'));
    }

    public function getFaqs(){
        $faqs = Faq::all();
        $flag = "faqsList";
        return View::make('pages.backend.page.faq.list', compact('flag', 'faqs'));
    }
    public function getFaqAddPage(){
        $isEdit = false;
        $flag = "faqAdd";
        return View::make('pages.backend.page.faq.add', compact('flag', 'isEdit'));
    }
    public function getFaqEditPage($id){
        $isEdit = true;
        $faq = Faq::find($id);
        $flag = "faqAdd";
        return View::make('pages.backend.page.faq.add', compact('flag', 'isEdit', 'faq'));
    }
    public function createFaq(){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $faq = new Faq();
            $faq->title = Input::get('name');
            $faq->content = Input::get('description');
            $faq->isShow = 1;

            $faq->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateFaq($id){
        $rules = array(
            'name' => 'required',
            'description' =>'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $faq = Faq::find($id);
            $faq->title = Input::get('name');
            $faq->content = Input::get('description');
            $faq->isShow = 1;

            $faq->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function deleteFaq($id){
        Faq::destroy($id);
        return Redirect::back()->with('message', "It has been deleted successfully.");
    }
}
