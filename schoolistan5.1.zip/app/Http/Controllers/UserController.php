<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use App\User;
use App\Role;

class UserController extends BaseController
{
    public function businessList(){
        $users = User::all();
        $flag = "usersBusinessList";
        return View::make('pages.backend.user.list', compact('flag', 'users'));
    }
    public function businessAdd(){
        $roles = Role::all();
        $flag = "userBusinessAdd";
        return View::make('pages.backend.user.add', compact('flag', 'roles'));
    }
    public function subscribersList(){
        $users = User::all();
        $flag = "usersSubscribersList";
        return View::make('pages.backend.user.list', compact('flag', 'users'));
    }
    public function subscriberAdd(){
        $roles = Role::all();
        $flag = "userSubscriberAdd";
        return View::make('pages.backend.user.add', compact('flag', 'roles'));
    }
    public function getProfilePage(){
        $flag = "profile";
        $user = User::find(Session::get('user')->id);
        return View::make('pages.frontend.profile', compact('flag', 'user'));
    }
    public function updateUser($id){
        $rules = array(
            'name' => 'required',
            'about' =>'required',
            'gender' =>'required',
            'phone' =>'required',
            'username' =>'required',
            'email' => 'required',
            'city' => 'required',
            'country' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $user = User::find($id);
            $user->full_name = Input::get('name');
            $user->about = Input::get('about');
            $user->gender = Input::get('gender');
            $user->phone = Input::get('phone');
            $user->username = Input::get('username');
            $user->email = Input::get('email');
            $user->city = Input::get('city');
            $user->country = Input::get('country');
            $user->save();

            return Redirect::back()->with('message', "It has been updated successfully.");
        }
    }
    public function changePassword($id){
        $old = Input::get('old_password');
        $user = User::find($id);

        if($user->password != hash('md5',$old)) {
            return Redirect::back()->withErrors("Current Password is wrong.");
        }

        $new = Input::get('new_password');
        $confirm = Input::get('confirm_password');

        if($new != $confirm){
            return Redirect::back()->withErrors("Password and confirm password don't match.");
        }

        $user->password = hash('md5', $new);
        $user->save();

        return Redirect::back()->with('message', "It has been changed successfully.");
    }
    public function changeAvatar($id){
        $date = new DateTime();
        $user = User::find($id);

        if(Input::hasFile('avatar')){
            $filename = 'avatar_'.$date->getTimestamp(). '.' .
                Input::file('avatar')->getClientOriginalExtension();

            Input::file('avatar')->move(
                base_path() . '/public/images/user/', $filename
            );
            $user->avatar = $filename;
        }

        $user->save();

        Session::forget('user');

        Session::put('user',$user);

        return Redirect::back()->with('message', "It has been changed successfully.");
    }
}
