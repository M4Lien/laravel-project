<?php

namespace App\Http\Controllers;
use App\EventCategory;
use App\OurEvent;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

class EventCategoryController extends BaseController
{
    public function getCategoryList(){
        $flag = "eventCategoryList";
        $categories = EventCategory::all();
        return View::make('pages.backend.eventCategory.list', compact('flag', 'categories'));
    }
    public function getCategoryAdd(){
        $isEdit = false;
        $flag = "eventCategoryAdd";
        return View::make('pages.backend.eventCategory.add', compact('flag', 'isEdit'));
    }
    public function postCategoryAdd(){
        $rules = array(
            'name' => 'required',
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $category = new EventCategory();
            $category->name = Input::get('name');
            $category->description = Input::get('description');
            $category->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateCategory($id){
        $rules = array(
            'name' => 'required',
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $category = EventCategory::find($id);
            $category->name = Input::get('name');
            $category->description = Input::get('description');
            $category->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getCategoryEdit($id){
        $flag = "eventCategoryAdd";
        $isEdit = true;
        $category = EventCategory::find($id);
        return View::make('pages.backend.eventCategory.add', compact('flag', 'category', 'isEdit'));
    }
    public function deleteCategory($id){
        $activity = OurEvent::where('category_id', $id)->get();
        if($activity->count() == 0){
            EventCategory::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. There are events associated with this category.");
        }
    }
}
