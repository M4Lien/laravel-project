<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

use App\PostCategory;

class PostCategoryController extends BaseController
{
    public function getCategoryList(){
        $flag = "postCategoryList";
        $categories = PostCategory::all();
        return View::make('pages.backend.postCategory.list', compact('flag', 'categories'));
    }
    public function getCategoryAdd(){
        $isEdit = false;
        $flag = "postCategoryAdd";
        return View::make('pages.backend.postCategory.add', compact('flag', 'isEdit'));
    }
    public function postCategoryAdd(){
        $rules = array(
            'name' => 'required',
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $category = new PostCategory();
            $category->name = Input::get('name');
            $category->description = Input::get('description');
            $category->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function updateCategory($id){
        $rules = array(
            'name' => 'required',
            'description' => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);
        if($validator->fails()){
            return Redirect::back()->withErrors($validator);
        }else{
            $category = PostCategory::find($id);
            $category->name = Input::get('name');
            $category->description = Input::get('description');
            $category->save();

            return Redirect::back()->with('message', "It has been registered successfully.");
        }
    }
    public function getCategoryEdit($id){
        $flag = "postCategoryAdd";
        $isEdit = true;
        $category = PostCategory::find($id);
        return View::make('pages.backend.postCategory.add', compact('flag', 'category', 'isEdit'));
    }
    public function deleteCategory($id){
        $activity = Post::where('category_id', $id)->get();
        if($activity->count() == 0){
            PostCategory::destroy($id);
            return Redirect::back()->with('message', "It has been deleted successfully.");
        }else{
            return Redirect::back()->withErrors("It has not been deleted successfully. There are posts associated with this category.");
        }
    }
}
