<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\PageSetting;

class SocialController extends BaseController
{
    public function getSocialLink(){
        $flag = "socialLink";
        return View::make('pages.backend.cms.socials', compact('flag'));
    }
    public function postSocialLink()
    {
        if(!Input::has('facebook') && !Input::has('twitter') && !Input::has('google') && !Input::has('instagram') &&!Input::has('youtube')){
            Redirect::back();
        }
        $params = ['facebook', 'twitter', 'google', 'instagram', 'youtube'];
        foreach ($params as $param) {
            if(Input::has($param)){
                $page = PageSetting::where('type', 'social')->where('property', $param)->first();
                if (!$page) {
                    $page = new PageSetting();
                    $page->type = 'social';
                    $page->property = $param;
                    $page->value = Input::get($param);
                    $page->save();
                } else {
                    $page->value = Input::get($param);
                    $page->save();
                }
            }
        }
        return Redirect::back()->with('message', "It has been registered successfully.");
    }
}
