<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
use App\PageSetting;
use App\Place;
use App\Activity;
use App\Testimonial;
use App\OurEvent;
use App\Post;
use App\ActivityCategory;
use App\Curriculum;
use App\Facility;
use App\Advertisement;

Route::get('/', function () {
    $testimonials = Testimonial::take(3)->get();

    $events = OurEvent::take(4)->get();

    $posts = Post::take(3)->get();

    $activity_categories = ActivityCategory::where('isHomeShow', 1)->get();

    $categories = ActivityCategory::where('IsHomeShow', 1)->get();

    $response = [];
    $items = PageSetting::where('type', 'home')->orWhere('type', 'about')->get();
    foreach($items as $item){
        $response[$item->property] = $item->value;
    }

    $curriculum = Curriculum::all();

    $ad_left = Advertisement::where('page', 'home')->where('position', 'left')->first();
    $ad_right = Advertisement::where('page', 'home')->where('position', 'right')->first();

    $flag = "home";

    return View::make('pages.frontend.home', compact('flag', 'response', 'testimonials', 'events', 'activity_categories', 'posts', 'curriculum', 'categories', 'ad_left', 'ad_right'));
});

Route::get('/search/{item}/{category}/{word}/result', function($item, $category, $word){
    if($item == 'school'){
        if($category == 'all'){
            $results = Place::where('isSchool', 1)->where('name', 'LIKE', '%'.$word.'%');
        }else{
            $results = Place::where('isSchool', 1)->where('curriculum_id', $category)->where('name', 'LIKE', '%'.$word.'%');
        }
    }
    if($item == 'nursery'){
        if($category == 'all'){
            $results = Place::where('isNursery', 1)->where('name', 'LIKE', '%'.$word.'%');
        }else{
            $results = Place::where('isNursery', 1)->where('curriculum_id', $category)->where('name', 'LIKE', '%'.$word.'%');
        }
    }
    if($item == 'activity'){
        if($category == 'all'){
            $results = Activity::where('name', 'LIKE', '%'.$word.'%');
        }else{
            $results = Activity::where('category_id', $category)->where('name', 'LIKE', '%'.$word.'%');
        }
    }
    $testimonials = Testimonial::all();
    $results = $results->paginate(6);
    $facilities = Facility::all();
    $curriculum = Curriculum::all();
    $flag = 'search';
    return View::make('pages.frontend.search_result', compact('flag', 'facilities', 'curriculum', 'item', 'results', 'testimonials'));
});

Route::get('/search/{item}/{category}/result', function($item, $category){
    if($item == 'school'){
        if($category == 'all'){
            $results = Place::where('isSchool', 1);
        }else{
            $results = Place::where('isSchool', 1)->where('curriculum_id', $category);
        }
    }
    if($item == 'nursery'){
        if($category == 'all'){
            $results = Place::where('isNursery', 1);
        }else{
            $results = Place::where('isNursery', 1)->where('curriculum_id', $category);
        }
    }
    if($item == 'activity'){
        if($category == 'all'){
            $results = Activity::all();
        }else{
            $results = Activity::where('category_id', $category);
        }
    }
    $testimonials = Testimonial::all();
    $results = $results->paginate(6);
    $facilities = Facility::all();
    $curriculum = Curriculum::all();
    $flag = 'search';
    return View::make('pages.frontend.search_result', compact('flag', 'facilities', 'curriculum', 'results', 'item', 'testimonials'));
});

/*
 * Authentication
 */

Route::get('/logout', 'AuthController@logout');
Route::post('/login', ['as'=>'login', 'uses'=>'AuthController@login']);
Route::post('/register', ['as'=>'register', 'uses'=>'AuthController@postRegister']);
Route::get('/activate/{code}', 'AuthController@activateAccount');
/*
 * Front-end
 */

Route::get('/about', function () {
    $testimonials = Testimonial::take(3)->get();
    $activity_categories = ActivityCategory::where('isHomeShow', 1)->limit(4)->get();
    $response = [];
    $items = PageSetting::where('type', 'about')->get();
    foreach($items as $item){
        $response[$item->property] = $item->value;
    }

    $flag = "about";
    return View::make('pages.frontend.about', compact('flag', 'testimonials', 'activity_categories', 'response'));
});
Route::get('/contact', 'ContactController@getContactPage');
Route::post('/contact/create', ['as'=>'contact.create', 'uses'=>'ContactController@createContact']);

Route::get('/blog', 'PostController@getPostListForFront');
Route::get('/blog/{id}', ['as' => 'blog.single', 'uses' =>'PostController@getPostForFront']);
Route::post('/blog/search', ['as' => 'blog.search', 'uses'=>'PostController@getSearchResult']);
Route::get('/blog/category/{id}', ['as' => 'blog.category', 'uses' =>'PostController@getPostByCategoryForFront']);

Route::get('/search/school/all', ['as'=>'school.all', 'uses'=>'SchoolController@getSchoolsForFront']);
Route::get('/search/school/{id}', ['as'=>'school.single', 'uses'=>'SchoolController@getSchoolForFront']);

Route::get('/search/institute/all', ['as'=>'institute.all', 'uses'=>'InstituteController@getInstitutesForFront']);
Route::get('/search/institute/{id}', ['as'=>'institute.single', 'uses'=>'InstituteController@getInstituteForFront']);
Route::post('/institute/review', ['as'=>'review.create', 'uses' => 'InstituteController@createReview']);

Route::get('/search/activity/{category}', ['as'=>'activity.all', 'uses'=>'ActivityController@getActivitiesForFront']);
Route::get('/search/activity/item/{id}', ['as'=>'activity.single', 'uses'=>'ActivityController@getActivityForFront']);

Route::get('/search/nursery/all', ['as'=>'nursery.all', 'uses'=>'NurseryController@getNurseriesForFront']);
Route::get('/search/nursery/{id}', ['as'=>'nursery.single', 'uses'=>'NurseryController@getNurseryForFront']);

Route::get('/upcoming_events', 'EventController@getEventsForFront');
Route::get('/events_gallery', 'EventController@getGalleryForFront');
Route::get('/event/{id}', ['as'=>'event.single', 'uses'=>'EventController@getEventForFront']);
Route::get('/event/gallery/{id}', ['as'=>'gallery.show', 'uses'=>'EventController@showGallery']);
Route::get('/eventSearch/{date}/{keyword}', 'EventController@getSearchResult');
Route::get('/eventSearch/{date}', 'EventController@getSearchResultWithoutKey');
Route::get('/eventNow/{now}', 'EventController@getSearchResultForNow');

Route::get('/faqs', 'FaqController@getFaqsForFront');

Route::get('/googleMap/{lat}/{lng}', function($lat, $lng){
    $flag = "events";
    return View::make('pages.frontend.map', compact('flag', 'lat', 'lng'));
});

Route::group(['before'=>'auth'], function(){
    Route::get('/profile', 'UserController@getProfilePage');
    Route::post('/profile/update/{id}', ['as'=>'user.update', 'uses'=>'UserController@updateUser']);
    Route::post('/profile/changePassword/{id}', ['as'=>'password.change', 'uses'=>'UserController@changePassword']);
    Route::post('/profile/changeAvatar/{id}', ['as'=>'avatar.change', 'uses'=>'UserController@changeAvatar']);
});

/*
 * ---------------------------------Backend--------------------------------------------------
 */

/*
 * Dashboard
 */
Route::group(['before' => 'auth'], function () {
    Route::get('/admin', ['before' => 'auth', function () {
        $flag = "dashboard";
        return View::make('pages.backend.dashboard', compact('flag'));
    }]);
    /*
     * Nurseries
     */
    Route::get('/backend/nurseries/list', ['as'=>'nurseries.list', 'uses'=>'NurseryController@getNurseries']);
    Route::get('/backend/nursery/add', ['as'=>'nursery.add', 'uses'=>'NurseryController@getNurseryAddPage']);
    Route::post('/backend/nursery/add', ['as'=>'nursery.create', 'uses'=>'NurseryController@createNursery']);
    Route::get('/backend/nursery/edit/{id}', ['as'=>'nursery.edit', 'uses'=>'NurseryController@getNurseryEditPage']);
    Route::post('/backend/nursery/update/{id}', ['as'=>'nursery.update', 'uses'=>'NurseryController@updateNursery']);
    Route::get('/backend/nursery/delete/{id}', ['as'=>'nursery.delete', 'uses'=>'NurseryController@deleteNursery']);
    /*
     * Schools
     */
    Route::get('/backend/schools/list', ['as'=>'schools.list', 'uses'=>'SchoolController@getSchools']);
    Route::get('/backend/school/add', ['as'=>'school.add', 'uses'=>'SchoolController@getSchoolAddPage']);
    Route::post('/backend/school/add', ['as'=>'school.create', 'uses'=>'SchoolController@createSchool']);
    Route::get('/backend/school/edit/{id}', ['as'=>'school.edit', 'uses'=>'SchoolController@getSchoolEditPage']);
    Route::post('/backend/school/update/{id}', ['as'=>'school.update', 'uses'=>'SchoolController@updateSchool']);
    Route::get('/backend/school/delete/{id}', ['as'=>'school.delete', 'uses'=>'SchoolController@deleteSchool']);
    /*
     * Institutes
     */
    Route::get('/backend/institutes/list', ['as'=>'institutes.list', 'uses'=>'InstituteController@getInstitutes']);
    Route::get('/backend/institute/add', ['as'=>'institute.add', 'uses'=>'InstituteController@getInstituteAddPage']);
    Route::post('/backend/institute/create', ['as'=>'institute.create', 'uses'=>'InstituteController@createInstitute']);
    Route::get('/backend/institute/edit/{id}', ['as'=>'institute.edit', 'uses'=>'InstituteController@getInstituteEditPage']);
    Route::post('/backend/institute/update/{id}', ['as'=>'institute.update', 'uses'=>'InstituteController@updateInstitute']);
    Route::get('/backend/institute/delete/{id}', ['as'=>'institute.delete', 'uses'=>'InstituteController@deleteInstitute']);
    /*
     * Users
     */
    Route::get('/backend/users/business/list', ['as'=>'users.business.list', 'uses'=>'UserController@businessList']);
    Route::get('/backend/user/business/add', ['as'=>'user.business.add', 'uses'=>'UserController@businessAdd']);
    Route::get('/backend/users/subscribers/list', ['as'=>'users.subscribers.list', 'uses'=>'UserController@subscribersList']);
    Route::get('/backend/users/subscriber/add', ['as'=>'user.subscriber.add', 'uses'=>'UserController@subscriberAdd']);

    /*
     * Blog
     */
    Route::get('/backend/blog/list', ['as'=>'blog.list', 'uses'=>'PostController@getPostList']);
    Route::get('/backend/blog/add', ['as'=>'blog.add', 'uses'=>'PostController@goAddPage']);
    Route::post('/backend/blog/post/create', ['as'=>'post.create', 'uses'=>'PostController@createPost']);
    Route::post('/blog/comment', ['as'=>'comment.create', 'uses'=>'PostController@createComment']);
    Route::post('/blog/comment/reply', ['as'=>'reply.create', 'uses'=>'PostController@createReply']);
    Route::get('/backend/blog/edit/{id}', ['as'=>'post.edit', 'uses'=>'PostController@goEditPage']);
    Route::post('/backend/blog/update/{id}', ['as'=>'post.update', 'uses'=>'PostController@updatePost']);
    Route::get('/backend/blog/delete/{id}', ['as'=>'post.delete', 'uses'=>'PostController@deletePost']);
    /*
     * Events
     */
    Route::get('/backend/events/list', ['as'=>'events.list', 'uses'=>'EventController@getEventList']);
    Route::get('/backend/event/add', ['as'=>'event.add', 'uses'=>'EventController@getEventAddPage']);
    Route::post('/backend/event/add', ['as'=>'event.store', 'uses'=>'EventController@postEvent']);
    Route::get('/backend/event/edit/{id}', ['as'=>'event.edit', 'uses'=>'EventController@getEventEditPage']);
    Route::post('/backend/event/update/{id}', ['as'=>'event.update', 'uses'=>'EventController@updateEvent']);
    Route::get('/backend/event/delete/{id}', ['as'=>'event.delete', 'uses'=>'EventController@deleteEvent']);
    Route::get('/backend/events/gallery/list', ['as'=>'gallery.list', 'uses'=>'EventController@getGalleryList']);
    Route::get('/backend/events/gallery/add', ['as'=>'gallery.add', 'uses'=>'EventController@getGalleryAddPage']);
    Route::get('/backend/events/gallery/edit/{id}', ['as'=>'gallery.edit', 'uses'=>'EventController@getGalleryEditPage']);
    Route::get('/backend/events/gallery/delete/{id}', ['as'=>'gallery.delete', 'uses'=>'EventController@deleteGallery']);
    Route::get('/backend/events/gallery/image/{id}', ['as'=>'image.delete', 'uses'=>'EventController@deleteImage']);
    Route::post('/backend/events/gallery/upload', ['as'=>'gallery.imageUpload', 'uses'=>'EventController@imageUpload']);
    /*
     * Manage Page
     */
    Route::get('/backend/page/home', ['as'=>'home.add', 'uses'=>'PageSettingController@getHome']);
    Route::post('/backend/page/home', ['as'=>'home.store', 'uses'=>'PageSettingController@postHome']);

    Route::get('/backend/page/about', ['as'=>'about.add', 'uses'=>'PageSettingController@getAbout']);
    Route::post('/backend/page/about', ['as'=>'about.store', 'uses'=>'PageSettingController@postAbout']);

    Route::get('/backend/page/nurseries', ['as'=>'nurseries.add', 'uses'=>function () {
        $flag = "nurseriesAdd";
        return View::make('pages.backend.page.nurseries', compact('flag'));
    }]);
    Route::get('/backend/page/institutes', ['as'=>'institutes.add', 'uses'=>function () {
        $flag = "institutesAdd";
        return View::make('pages.backend.page.institutes', compact('flag'));
    }]);
    Route::get('/backend/page/events', ['as'=>'events.add', 'uses'=>function () {
        $flag = "eventsAdd";
        return View::make('pages.backend.page.events', compact('flag'));
    }]);
    Route::get('/backend/page/blogs', ['as'=>'blogs.add', 'uses'=>function () {
        $flag = "blogsAdd";
        return View::make('pages.backend.page.blogs', compact('flag'));
    }]);
    Route::get('/backend/page/contacts', ['as'=>'contacts.add', 'uses'=>'ContactController@getContactBackendPage']);
    Route::post('/backend/page/contacts', ['as'=>'contacts.store', 'uses'=>'ContactController@postContactBackendPage']);

    Route::get('/backend/page/terms', ['as'=>'terms.add', 'uses'=>function () {
        $flag = "termsAdd";
        return View::make('pages.backend.page.terms', compact('flag'));
    }]);
    Route::get('/backend/page/policy', ['as'=>'policy.add', 'uses'=>function () {
        $flag = "policyAdd";
        return View::make('pages.backend.page.policy', compact('flag'));
    }]);

    Route::get('/backend/page/testimonials/list', ['as'=>'testimonials.list', 'uses'=>'TestimonialController@getTestimonialList']);
    Route::get('/backend/page/testimonial/add', ['as'=>'testimonial.add', 'uses'=>'TestimonialController@getTestimonialAdd']);
    Route::post('/backend/page/testimonial/add', ['as'=>'testimonial.store', 'uses'=>'TestimonialController@postTestimonialAdd']);
    Route::get('/backend/page/testimonial/edit/{id}', ['as'=>'testimonial.edit', 'uses'=>'TestimonialController@getTestimonialEdit']);
    Route::post('/backend/page/testimonial/update/{id}', ['as'=>'testimonial.update', 'uses'=>'TestimonialController@updateTestimonial']);
    Route::get('/backend/page/testimonial/delete/{id}', ['as'=>'testimonial.delete', 'uses'=>'TestimonialController@deleteTestimonial']);

    Route::get('/backend/page/faqs/list', ['as'=>'faqs.list', 'uses'=>'FaqController@getFaqs']);
    Route::get('/backend/page/faq/add', ['as'=>'faq.add', 'uses'=>'FaqController@getFaqAddPage']);
    Route::post('/backend/page/faq/add', ['as'=>'faq.create', 'uses'=>'FaqController@createFaq']);
    Route::get('/backend/page/faq/edit/{id}', ['as'=>'faq.edit', 'uses'=>'FaqController@getFaqEditPage']);
    Route::post('/backend/page/faq/update/{id}', ['as'=>'faq.update', 'uses'=>'FaqController@updateFaq']);
    Route::get('/backend/page/faq/delete/{id}', ['as'=>'faq.delete', 'uses'=>'FaqController@deleteFaq']);
    /*
     * CMS
     */
    Route::get('/backend/cms/socials/add', ['as'=>'socials.add', 'uses'=>'SocialController@getSocialLink']);
    Route::post('/backend/cms/socials/add', ['as'=>'socials.store', 'uses'=>'SocialController@postSocialLink']);

    Route::get('/backend/curriculum/list', ['as'=>'curriculum.list', 'uses'=>'CurriculumController@getCurriculumList']);
    Route::get('/backend/curriculum/add', ['as'=>'curriculum.add', 'uses'=>'CurriculumController@getCurriculumAdd']);
    Route::post('/backend/curriculum/add', ['as'=>'curriculum.create', 'uses'=>'CurriculumController@createCurriculum']);
    Route::get('/backend/curriculum/edit/{id}', ['as'=>'curriculum.edit', 'uses'=>'CurriculumController@getCurriculumEdit']);
    Route::post('/backend/curriculum/update/{id}', ['as'=>'curriculum.update', 'uses'=>'CurriculumController@updateCurriculum']);
    Route::get('/backend/curriculum/delete/{id}', ['as'=>'curriculum.delete', 'uses'=>'CurriculumController@deleteCurriculum']);

    Route::get('/backend/category/list', ['as'=>'category.list', 'uses'=>'CategoryController@getCategoryList']);
    Route::get('/backend/category/add', ['as'=>'category.add', 'uses'=>'CategoryController@getCategoryAdd']);
    Route::post('/backend/category/add', ['as'=>'category.store', 'uses'=>'CategoryController@postCategoryAdd']);
    Route::get('/backend/category/edit/{id}', ['as'=>'category.edit', 'uses'=>'CategoryController@getCategoryEdit']);
    Route::post('/backend/category/update/{id}', ['as'=>'category.update', 'uses'=>'CategoryController@updateCategory']);
    Route::get('/backend/category/delete/{id}', ['as'=>'category.delete', 'uses'=>'CategoryController@deleteCategory']);
    Route::get('/backend/category/homeShow/{id}', ['as'=>'category.homeShow', 'uses'=>'CategoryController@showHome']);

    Route::get('/backend/facility/list', ['as'=>'facility.list', 'uses'=>'FacilityController@getFacilityList']);
    Route::get('/backend/facility/add', ['as'=>'facility.add', 'uses'=>'FacilityController@getFacilityAdd']);
    Route::post('/backend/facility/add', ['as'=>'facility.store', 'uses'=>'FacilityController@postFacilityAdd']);
    Route::get('/backend/facility/edit/{id}', ['as'=>'facility.edit', 'uses'=>'FacilityController@getFacilityEdit']);
    Route::post('/backend/facility/update/{id}', ['as'=>'facility.update', 'uses'=>'FacilityController@updateFacility']);
    Route::get('/backend/facility/delete/{id}', ['as'=>'facility.delete', 'uses'=>'FacilityController@deleteFacility']);

    Route::get('/backend/eventCategory/list', ['as'=>'eventCategory.list', 'uses'=>'EventCategoryController@getCategoryList']);
    Route::get('/backend/eventCategory/add', ['as'=>'eventCategory.add', 'uses'=>'EventCategoryController@getCategoryAdd']);
    Route::post('/backend/eventCategory/add', ['as'=>'eventCategory.store', 'uses'=>'EventCategoryController@postCategoryAdd']);
    Route::get('/backend/eventCategory/edit/{id}', ['as'=>'eventCategory.edit', 'uses'=>'EventCategoryController@getCategoryEdit']);
    Route::post('/backend/eventCategory/update/{id}', ['as'=>'eventCategory.update', 'uses'=>'EventCategoryController@updateCategory']);
    Route::get('/backend/eventCategory/delete/{id}', ['as'=>'eventCategory.delete', 'uses'=>'EventCategoryController@deleteCategory']);

    Route::get('/backend/postCategory/list', ['as'=>'postCategory.list', 'uses'=>'PostCategoryController@getCategoryList']);
    Route::get('/backend/postCategory/add', ['as'=>'postCategory.add', 'uses'=>'PostCategoryController@getCategoryAdd']);
    Route::post('/backend/postCategory/add', ['as'=>'postCategory.store', 'uses'=>'PostCategoryController@postCategoryAdd']);
    Route::get('/backend/postCategory/edit/{id}', ['as'=>'postCategory.edit', 'uses'=>'PostCategoryController@getCategoryEdit']);
    Route::post('/backend/postCategory/update/{id}', ['as'=>'postCategory.update', 'uses'=>'PostCategoryController@updateCategory']);
    Route::get('/backend/postCategory/delete/{id}', ['as'=>'postCategory.delete', 'uses'=>'PostCategoryController@deleteCategory']);

    Route::get('/backend/activities/list', ['as'=>'activities.list', 'uses'=>'ActivityController@getActivities']);
    Route::get('/backend/activity/add', ['as'=>'activity.add', 'uses'=>'ActivityController@getActivityAddPage']);
    Route::post('/backend/activity/create', ['as'=>'activity.create', 'uses'=>'ActivityController@createActivity']);
    Route::get('/backend/activity/edit/{id}', ['as'=>'activity.edit', 'uses'=>'ActivityController@getActivityEditPage']);
    Route::post('/backend/activity/update/{id}', ['as'=>'activity.update', 'uses'=>'ActivityController@updateActivity']);
    Route::get('/backend/activity/delete/{id}', ['as'=>'activity.delete', 'uses'=>'ActivityController@deleteActivity']);

    Route::get('/backend/advertise/add', ['as'=>'advertise.add', 'uses'=>'AdvertisementController@getAdvertiseAddPage']);
    Route::get('/backend/advertises/list',['as'=>'advertises.list', 'uses'=>'AdvertisementController@getAdvertises']);
    Route::post('/backend/advertise/add', ['as'=>'advertise.create', 'uses'=>'AdvertisementController@createAdvertise']);
    Route::post('/backend/advertise/update/{id}', ['as'=>'advertise.update', 'uses'=>'AdvertisementController@updateAdvertise']);
    Route::get('/backend/advertise/edit/{id}', ['as'=>'advertise.edit', 'uses'=>'AdvertisementController@getAdvertiseEditPage']);
    Route::get('/backend/advertise/delete/{id}', ['as'=>'advertise.delete', 'uses'=>'AdvertisementController@deleteAdvertise']);

});
/*
 * Get Contact Info
 */
$pages = PageSetting::where('type', 'contact')->get();
$result = [];
foreach($pages as $page){
    $result[$page->property] = $page->value;
}
View::share('contact', $result);
/*
 * Get Social Link
 */
$pages = PageSetting::where('type', 'social')->get();
$result = [];
foreach($pages as $page){
    $result[$page->property] = $page->value;
}
View::share('social', $result);

$amount = [];
$amount['school'] = Place::where('isSchool', 1)->get()->count();
$amount['nursery'] = Place::where('isNursery', 1)->get()->count();
$amount['activity'] = Activity::all()->count();
$amount['institute'] = 1;
View::share('amount', $amount);
