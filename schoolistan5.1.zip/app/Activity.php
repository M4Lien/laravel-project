<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Activity extends Model {

	protected $table = 'activities';

	protected $fillable = ['name', 'description', 'logo', 'institute_id'];

    public $timestamps = false;

    public function getInstitute(){
        return $this->hasOne(Institute::class, 'id', 'institute_id');
    }
}
