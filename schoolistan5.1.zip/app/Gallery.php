<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gallery extends Model {

	protected $table = 'galleries';

	protected $fillable = ['name', 'event_id', 'description'];

    public $timestamps = false;

    public function getEvent(){
        return $this->hasOne(OurEvent::class, 'id', 'event_id');
    }

}
