<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OurEvent extends Model {

	protected $table = 'events';

	protected $fillable = ['name', 'description', 'min_time', 'max_time', 'date', 'cost', 'category_id', 'tag', 'logo', 'user_id', 'venue_name', 'venue_phone', 'venue_lat', 'venue_lng', 'organizer_name', 'organizer_phone', 'organizer_email', 'organizer_site', 'organizer_address'];

    protected $appends = ['location'];

    public $timestamps = false;

    public function getCategory(){
        return $this->hasOne(EventCategory::class, 'id', 'category_id');
    }

    public function getUser(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }

//    public function getLocationAttribute(){
//        $latitude = $this->venue_lat;
//        $longitude = $this->venue_lng;
//
//        $geocodeFromLatLong = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($latitude).','.trim($longitude).'&sensor=false');
//        $output = json_decode($geocodeFromLatLong);
//        $status = $output->status;
//        $address = ($status=="OK")?$output->results[1]->formatted_address:'';
//        return $address;
//    }
}
