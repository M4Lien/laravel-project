<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class PageSetting extends Model {

	protected $table = 'page_settings';

	protected $fillable = ['type', 'property', 'value'];

    public $timestamps = false;
}
