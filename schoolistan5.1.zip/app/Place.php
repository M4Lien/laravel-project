<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Place extends Model {

	protected $table = 'places';

	protected $fillable = ['name', 'location', 'curriculum_id', 'min_age', 'max_age', 'phone', 'site_address', 'description', 'logo', 'thumbnail', 'fee', 'admission', 'isSchool', 'isNursery'];

    public function getCurriculum(){
        return $this->hasOne(Curriculum::class, 'id', 'curriculum_id');
    }

    public $timestamps = false;
}
