<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActivityCategory extends Model {

	protected $table = 'activity_categories';

	protected $fillable = ['name', 'description', 'icon', 'IsHomeShow'];

    public $timestamps = false;
}
